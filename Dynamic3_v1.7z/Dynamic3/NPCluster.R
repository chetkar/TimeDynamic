# @file NPCluster.R
#
# @author Subha Guha
# @author Marc A. Suchard

#' NPCluster
#'
#' @docType package
#' @name NPCluster
#' @useDynLib NPCluster, .registration = TRUE
NULL
