# While coming from fast_PDP.functions.R
fn3.update.element.objects <- function(parm , computeMode )
{
	#Update S (they are numbered sequentially)
	#parm <- fn.s(parm)
	level.v <- unlist(parm$clust$auto$level)
	c.v     <- unlist(parm$clust$c.v)
		
	for(i in 1:parm$h ){
		k   <- length(unique(as.vector(unlist(parm$clust$s.mt[[i]]))))
	
		parm$clust$n.vec[[i]] <- rep(NA,k)
		parm$clust$phi.v[[i]] <- rep(NA,k)
		
		for(gg in 1:k){
			parm$clust$n.vec[[i]][gg] <- length( which(as.vector(unlist(parm$clust$s.mt[[i]])) == gg) )
			parm$clust$phi.v[[i]][gg] <- parm$clust$A.mt[[i]][ which(as.vector(unlist(parm$clust$s.mt[[i]])) == gg)[1] ]				
		}
			parm$clust$K[[i]] <- k
	}

parm	
}

fn1.update.element.objects <- function(parm, computeMode)
	{

		 for(i in 1:parm$h){

		     parm$clust$s.mt[[i]]    <- matrix(parm$clust$s.v[[i]], c(parm$n2, parm$clust$G[i]))
			 parm$clust$A.mt[[i]]    <- matrix(parm$clust$phi.v[[i]][parm$clust$s.mt[[i]]], parm$n2)
			 parm$clust$theta.v[[i]] <- as.vector(parm$clust$A.mt)
		 }
	
		if(computeMode$computeC){

			all.n.vec <- .fastTabulateVector(parm$clust$s.v, parm$clust$K, TRUE)

			if(computeMode$computeR) {
				assertEqual(parm$clust$n0, all.n.vec[1])
				assertEqual(parm$clust$n.vec, all.n.vec[-1])
			}

			parm$clust$n0 <- all.n.vec[1]
			parm$clust$n.vec <- all.n.vec[-1]
		}

	parm
	}


fn2.update.element.objects <- function(parm, computeMode)
	{

		x     <- matrix(unlist(parm$X), parm$n2)
		for(i in 1:parm$h){
			
			parm$Y[[i]]  <- parm$X.sd[[i]]  <- matrix(NA,parm$n2, parm$clust$G[i])
			parm$Y1[[i]] <- parm$X1.sd[[i]] <- matrix(NA,parm$n2, parm$clust$G[i])
			parm$Y2[[i]] <- parm$X2.sd[[i]] <- matrix(NA,parm$n2, parm$clust$G[i])
			parm$Y3[[i]] <- parm$X3.sd[[i]] <- matrix(NA,parm$n2, parm$clust$G[i])
			parm$Y4[[i]] <- parm$X4.sd[[i]] <- matrix(NA,parm$n2, parm$clust$G[i])
			parm$Y5[[i]] <- parm$X5.sd[[i]] <- matrix(NA,parm$n2, parm$clust$G[i])
			x2.g.v <- x.g.v <- rep(NA, parm$n2 )
			
			parm$g[[i]] <- rep(1:parm$clust$G[i],each = parm$n2)
			
			
			for(g in 1:parm$clust$G[i])
			{
				I.g <- ( which( unlist(parm$clust$c.v) ==g & unlist(parm$clust$auto$level) == i ) )
				m.g <- length(I.g)
				
			    x.tmp <- matrix(x[, I.g ], parm$n2)
				
			
				if(m.g > 1)
				{
					x.g.v  <- rowMeans(x.tmp)
					x2.g.v <- rowMeans(x.tmp^2)
				}else{
					x.g.v  <- x.tmp
			
				}

				
				parm$Y[[i]][,g] <- x.g.v

				sd.g.v <- rep(0, parm$n2)
	
				if (m.g > 1)
				{
				sd.g.v <- sqrt((x2.g.v - x.g.v^2)*m.g/(m.g-1)  )
				}
		
				parm$X.sd[[i]][,g] <- sd.g.v
		
			####################################################
			### Split nbhd
			####################################################
		
			### Discrete
			### Data Type
		
			#Probit
			I1.g <-(parm$clust$c.v[[i]] == g & parm$data.type[[i]] == 1)
		
			if(sum(I1.g) > 0 ){
		
				x.g.v <- x.tmp <- parm$X[[i]][,I1.g]
				x2.g.v <- x.g.v^2
				m.g <- sum(I1.g)
		
				if (m.g > 1 )
				{
					x.g.v <- rowMeans(x.tmp)
					x2.g.v <- rowMeans(x.tmp^2)
				}

				parm$Y1[[i]][,g] <- x.g.v
				sd.g.v <- rep(0, parm$n2)
		
				if (m.g > 1)
				{# To make it numerically stable
					err <- 10^-10
					sd.g.v <- sqrt((x2.g.v - x.g.v^2)*m.g/(m.g-1) + err)
				}
		
				parm$X1.sd[[i]][,g] <- sd.g.v
			}
		
			### Continuous
			I2.g <-(parm$clust$c.v[[i]] == g & parm$data.type[[i]] == 2)
		
			if( sum(I2.g) > 0 ) {
				x.g.v <- x.tmp <- parm$X[[i]][,I2.g]
				x2.g.v <- x.g.v^2
				m.g <- sum(I2.g)
		
			if (m.g > 1 )
			{
				x.g.v <- rowMeans(x.tmp)
				x2.g.v <- rowMeans(x.tmp^2)
			}
			parm$Y2[[i]][,g] <- x.g.v
		
			sd.g.v <- rep(0, parm$n2)
			if (m.g > 1)
			{
			# To make it numerically stable
				err <- 10^-10
				sd.g.v <- sqrt((x2.g.v - x.g.v^2)*m.g/(m.g-1) + err)
			}

			parm$X2.sd[[i]][,g] <- sd.g.v
			}

			### Poisson
			I3.g <-(parm$clust$c.v[[i]] == g & parm$data.type[[i]] == 3)
			if( sum(I3.g) > 0 ) {
			x.g.v <- x.tmp <- parm$X[[i]][,I3.g]
			x2.g.v <- x.g.v^2
			m.g <- sum(I3.g)
			if (m.g > 1 )
			{
				x.g.v <- rowMeans(x.tmp)
				x2.g.v <- rowMeans(x.tmp^2)
			}
			parm$Y3[[i]][,g] <- x.g.v
		
			sd.g.v <- rep(0, parm$n2)
			if (m.g > 1)
			{
			# To make it numerically stable
			err <- 10^-10
			sd.g.v <- sqrt((x2.g.v - x.g.v^2)*m.g/(m.g-1) + err)
			}
			parm$X3.sd[[i]][,g] <- sd.g.v
			}		
		
			### Ordinal
			I4.g <-(parm$clust$c.v[[i]] == g & parm$data.type[[i]] == 4)
			if( sum(I4.g) > 0 ) {
			x.g.v <- x.tmp <- parm$X[[i]][,I4.g]
			x2.g.v <- x.g.v^2
			m.g <- sum(I4.g)
			if (m.g > 1 )
			{
			x.g.v <- rowMeans(x.tmp)
			x2.g.v <- rowMeans(x.tmp^2)
			}
			parm$Y4[[i]][,g] <- x.g.v
		
			sd.g.v <- rep(0, parm$n2)
			if (m.g > 1)
			{
			# To make it numerically stable
			err <- 10^-10
			sd.g.v <- sqrt((x2.g.v - x.g.v^2)*m.g/(m.g-1) + err)
			}
			parm$X4.sd[[i]][,g] <- sd.g.v
			}
		
		### Proportion
		I5.g <-(parm$clust$c.v[[i]] == g & parm$data.type[[i]] == 5)
		if( sum(I5.g) > 0 ) {
		x.g.v <- x.tmp <- parm$X[[i]][,I5.g]
		x2.g.v <- x.g.v^2
		m.g <- sum(I5.g)
		if (m.g > 1 )
		{
			x.g.v <- rowMeans(x.tmp)
			x2.g.v <- rowMeans(x.tmp^2)
		}
		parm$Y5[[i]][,g] <- x.g.v
		
		sd.g.v <- rep(0, parm$n2)
		 if (m.g > 1)
			{
			# To make it numerically stable
			err <- 10^-10
			sd.g.v <- sqrt((x2.g.v - x.g.v^2)*m.g/(m.g-1) + err)
			}
		parm$X5.sd[[i]][,g] <- sd.g.v
		}
		
		
		}
		
	}
	
	for(i in 1:parm$h){
			
		parm$N[[i]] 	<- parm$n2 * parm$clust$G[i]
		parm$Y[[i]] 	<- as.vector(parm$Y[[i]])
		parm$X.sd[[i]] 	<- as.vector(parm$X.sd[[i]])
		parm$Y1[[i]] 	<- as.vector(parm$Y1[[i]])
		parm$X1.sd[[i]] <- as.vector(parm$X1.sd[[i]])
		parm$Y2[[i]]  	<- as.vector(parm$Y2[[i]])
		parm$X2.sd[[i]] <- as.vector(parm$X2.sd[[i]])
		parm$Y3[[i]]  	<- as.vector(parm$Y3[[i]])
		parm$X3.sd[[i]] <- as.vector(parm$X3.sd[[i]])
		parm$Y4[[i]]  	<- as.vector(parm$Y4[[i]])
		parm$X4.sd[[i]] <- as.vector(parm$X4.sd[[i]])
		parm$Y5[[i]]  	<- as.vector(parm$Y5[[i]])
		parm$X5.sd[[i]] <- as.vector(parm$X5.sd[[i]])
	}
	#####################

	parm <- fn1.update.element.objects(parm, computeMode)

	parm
	
}


fn.element.DP <- function(data, parm, max.row.nbhd.size, row.frac.probes,
                          computeMode)
{

  if (parm$standardize.X)
  {parm <- fn.standardize_orient.X(parm)
  }

	# essentially, a Bush-Mac move: given groups, the parm$N=n2XG number of
	# invidividual elements (summaries of microarray elements) belonging to group g>0
	# are updated for s (phi) and z

	parm <- fn2.update.element.objects(parm, computeMode)
	
	parm <- element_fn.fast.DP(parm, data, max.row.nbhd.size, row.frac.probes, computeMode)

	#############################
	## Important: do not remove call to fn1.update.element.objects
	## updates A.mt, theta.v, B.mt, tBB.mt, s.v, s.mt, n.vec, n0
	#############################

	parm <- fn1.update.element.objects(parm, computeMode)

  	parm
}



