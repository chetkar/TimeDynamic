
PDP_fn.compact.consistency.check <- function(parm)
	{err <- 0

	for(l in 1:parm$h){

		gg <- length( unique( unlist(parm$clust$c.v)[ which(unlist(parm$clust$auto$level)==l)]) )
	
		if(gg != parm$clust$G[[l]]){
			
			
			err <- 1/2
		}
		
		for(g in 1:parm$clust$G[[l]] ){
		
			c.v  <- which( unlist(parm$clust$c.v) == g & unlist(parm$clust$auto$level)==l ) 	

			if ( length(c.v) != parm$clust$C.m.vec[[l]][g])
				{	err <- 1
				}
		}
	
		#if( ncol(parm$clust$A.mt[[l]]) != parm$clust$G[[l]] )	
		#{
		#	err <- 2
		#}			
	}
	
	err <- max(PDP_fn.consistency.check(parm),err)

	err
	}

PDP_fn.check.nbhd <- function(parm,l)
{
		max_dist.v <- array(,length(parm$clust$col.nbhd.k[[l]]))

		for (zz in 1:length(parm$clust$col.nbhd.k[[l]]))
		{
			v1 <- parm$clust$col_post.prob.mt[[l]][,parm$clust$col.nbhd.k[[l]][zz]]
			m1 <- matrix(parm$clust$col_post.prob.mt[[l]][,parm$clust$col.nbhd[[l]][[zz]]],ncol=length(parm$clust$col.nbhd[[l]][[zz]]))
			max_dist.v[zz] <- max(2*(1-colSums(sqrt(v1*m1))))
		}

		parm$clust$nbhd_max_dist[[l]] <- max(max_dist.v)
		

  parm
}

PDP_fn.consistency.check <- function(parm){

err <- 0
	
	for(l in 1:parm$h){
	
		if (length(parm$clust$n.vec[[l]]) != parm$clust$K[[l]])
			{err <- 9
			}

		if (length(parm$clust$phi.v[[l]]) != parm$clust$K[[l]])
			{err <- 10
			}
	
	}
	
	err
}


PDP_fn.swap.clusters <- function(parm, g1, g2, l, computeMode)
	{
	####################################################
	# swap the group labels g1 and g2
	####################################################

		ind     <- which( unlist(parm$clust$c.v) == g1 & unlist(parm$clust$auto$level) == l)	

		g.k     <- (ind - 1)%%parm$p + 1
		p.k     <- (ind - 1)%/%parm$p + 1
		
		for(i in 1: length(g.k) ){
	
			parm$clust$c.v[[ p.k[i] ]][g.k[i]] <- g2
		}
		
		buffer <- parm$clust$C.m.vec[[l]][g1]
		parm$clust$C.m.vec[[l]][g1] <- parm$clust$C.m.vec[[l]][g2]
		parm$clust$C.m.vec[[l]][g2] <- buffer
		
		buffer <- parm$clust$s.mt[[l]][,g1]
		parm$clust$s.mt[[l]][,g1] <- parm$clust$s.mt[[l]][,g2]
		parm$clust$s.mt[[l]][,g2] <- buffer
		
		parm$clust$s.v[[l]] <- as.vector(parm$clust$s.mt[[l]])
		
	#####################

		buffer <- parm$clust$A.mt[[l]][,g1]
		parm$clust$A.mt[[l]][,g1] <- parm$clust$A.mt[[l]][,g2]
		parm$clust$A.mt[[l]][,g2] <- buffer

		buffer <- parm$clust$B.mt[[l]][,(g1+1)]
		parm$clust$B.mt[[l]][,(g1+1)] <- parm$clust$B.mt[[l]][,(g2+1)]
		parm$clust$B.mt[[l]][,(g2+1)] <- buffer
	

	parm
	}

PDP_fn.clip.clusters <- function(parm, keep ,l )
	{
		parm$clust$s.mt[[l]]       <- parm$clust$s.mt[[l]][,keep]
		parm$clust$C.m.vec[[l]]    <- parm$clust$C.m.vec[[l]][keep]
		parm$clust$s.v[[l]]        <- as.vector(parm$clust$s.mt[[l]])

     	parm$clust$A.mt[[l]]       <- parm$clust$A.mt[[l]][,keep]

		indx2 <- c(1,(keep+1))
		parm$clust$B.mt[[l]]       <- parm$clust$B.mt[[l]][,indx2]

		if(parm$tBB_flag)
		{parm$clust$tBB.mt[[l]]    <- parm$clust$tBB.mt[[l]][indx2,indx2]
		}

		unq.s <- sort(unique(parm$clust$s.mt[[l]]))
		unq.a <- unique(parm$clust$A.mt[[l]])
		phi.v <- rep(NA, length(unq.s))
		n.vec <- rep(0, length(unq.s))
		
		for(i in unq.s){
			ind 	 <- which(parm$clust$s.mt[[l]]==i)
			phi.v[i] <- unq.a[ind[1]]
			n.vec[i] <- length(ind)
		}
		
		parm$clust$phi.v[[l]] <- phi.v
		parm$clust$K[[l]]     <- length(unq.s)
		parm$clust$n.vec[[l]] <- n.vec
	
		#parm <- element_fn.drop(parm)
	parm
	}

###########################################################
PDP_fn.log.lik <- function(gg, col, parm, data, jj, colSums=TRUE )
	{
		x 		 <- matrix(unlist(parm$X), parm$n2)
		xx       <- matrix(x[,col], parm$n2)

		a2.v      <- parm$clust$A.mt[[jj]][,gg]
		z.g.v     <- parm$clust$s.mt[[jj]][,gg] > 0
		log.lik.v <- rep(0,length(col)) ## HOT
		

		a2.1.v    <- as.vector(parm$clust$A.mt[[jj]][,gg])
		small.X.1 <- matrix(xx, ncol=length(col)) # HOT
	
		sd        <- parm$tau[[jj]]
		tmp       <- colSums(-.5*(small.X.1 - a2.1.v)^2/sd^2)
				  	
		log.lik.v <-  tmp 
		log.lik.v <- log.lik.v - parm$n2*(.5*log(2*pi) + mean(log(sd)) )
	
		log.lik.v
	}

#Edit this later	
PDP_fn.nbhd <- function(relative_I, parm, max.col.nbhd.size,l)
{
  	
  if (length(relative_I)>1)
  {relative_k <- sample(relative_I, size=1)
  }
  if (length(relative_I)==1)
  {relative_k <- relative_I
  }

  post.prob.mt <- parm$clust$col_subset_post.prob.mt[[l]]

  col.subset <- which(unlist(parm$clust$auto$level) == l)
  ind        <- which(relative_I %in% col.subset)
  tmp1.mt <- matrix(post.prob.mt[,ind], ncol = length(relative_I)) ## HOT
  
  ind    <- which(relative_k %in% col.subset)
  tmp2.v <- post.prob.mt[,ind]
  tmp3.mt <- sqrt(tmp1.mt * tmp2.v) ## HOT
  H.v <-  2 * (1 - colSums(tmp3.mt))

  cutoff <- parm$col.delta
  flag.v <- which(H.v <= cutoff)
  relative_I.k <- relative_I[flag.v]

  if (length(relative_I.k) > max.col.nbhd.size) {
    relative_I.k <- relative_I[rank(H.v, ties="random") <= max.col.nbhd.size]
  }

  relative_I.k <- sort(relative_I.k)

  relative_I <- sort(setdiff(relative_I, relative_I.k))
  relative_I <- sort(relative_I)

  list(relative_k, relative_I.k, relative_I)

}


PDP_fn.post.prob.and.delta <- function(parm,data, max.col.nbhd.size, col.frac.probes, computeMode) {
  
  parm$clust$col.nbhd    <- list()
  parm$clust$col.nbhd.k  <- list()

  
  if (computeMode$computeR) {

	for(l in 1:parm$h ){
	
		col.subset              <- which(unlist(parm$clust$auto$level)==l)
	
    ################################################
    ### Compute pmf of cluster variables w_1,...,w_p
    ###############################################
	
		prior.prob.v <- c(parm$clust$C.m.vec[[l]])
		small <- 1e-3 # compared to 1
		prior.prob.v[prior.prob.v < small] <- small

		subset_log.ss.mt <- array(, c(parm$clust$G[[l]], length(col.subset)))

		#parm <- fn.equivsd(parm,data)
		for (gg in 1:parm$clust$G[[l]])
		{
			col.subset              <- which(unlist(parm$clust$auto$level)==l)
			
			subset_log.ss.mt[(gg),] <- PDP_fn.log.lik(gg, col = col.subset,parm,data,l)
		}

		subset_log.ss.mt <- subset_log.ss.mt + log(prior.prob.v)

		maxx.v <- apply(subset_log.ss.mt, 2, max)

		subset_log.ss.mt <- t(t(subset_log.ss.mt) - maxx.v)
		subset_ss.mt <- exp(subset_log.ss.mt)

		col.sums.v <- colSums(subset_ss.mt)
		subset_ss.mt <- t(t(subset_ss.mt)/col.sums.v)

		# TODO Ask GS if second normalization is really necessary

		# replace zeros by "small"
		small2 <- 1e-5
		subset_ss.mt[subset_ss.mt < small2] <- small2

		# again normalize
		col.sums.v <- colSums(subset_ss.mt)
		subset_ss.mt <- t(t(subset_ss.mt)/col.sums.v)

		parm$clust$col_post.prob.mt[[l]] <- array(,c(parm$clust$G[[l]] , length(col.subset) ))
		parm$clust$col_post.prob.mt[[l]] <- subset_ss.mt
		
		#dimnames(parm$clust$col_post.prob.mt[[l]]) <- list(1:parm$clust$G[[l]], 1:length(col.subset))

		parm$clust$col_subset_post.prob.mt[[l]] <- subset_ss.mt
		#dimnames(parm$clust$col_subset_post.prob.mt[[l]]) <- list(1:parm$clust$G[[l]], 1:length(col.subset))

		#########################################
		### now compute the delta-neighborhoods
		#########################################

		if (computeMode$computeC) { # debugging
			savedSeed <- .GlobalEnv$.Random.seed # For debugging purposed only
		}

		#parm$clust$col.nbhd[[l]] <- NULL
		#parm$clust$col.nbhd.k[[l]] <- NULL
		#relative_I <- 1:length(col.subset)
		relative_I  <- which(unlist(parm$clust$auto$level)==l)

		tmp.list <- list()
		tmp.vec  <- c()
		count <- 0
		first <- TRUE
		while (length(relative_I) >= 1) {
			count <- count + 1
			
			tmp <- PDP_fn.nbhd(relative_I, parm, max.col.nbhd.size,l) # HOT inside function
			relative_k   <- tmp[[1]]
			relative_I.k <- tmp[[2]]
			relative_I   <- tmp[[3]]
      #
			if(first){
				tmp.list[[count]]          <- relative_I.k 
				tmp.vec                    <- relative_k
				
				#tmp.list[[count]]          <- col.subset[relative_I.k] 
				#parm$clust$col.nbhd.k[[l]] <- col.subset[relative_k]
				first <- FALSE
			}
			else{
				tmp.list[[count]]          <- relative_I.k
				tmp.vec                    <- c(tmp.vec,relative_k )
				#tmp.list[[count]]        <- col.subset[relative_I.k]
				#parm$clust$col.nbhd.k[[l]] <- c( parm$clust$col.nbhd.k[[l]],col.subset[relative_k] )
			}
			
			
		}
			count <- 0
			parm$clust$col.nbhd[[l]]   <- tmp.list
			parm$clust$col.nbhd.k[[l]] <- tmp.vec

		### SG: how good are these nbhds?

		#parm <- PDP_fn.check.nbhd(parm,l)

	 }	
	}

	if (computeMode$computeC) {

		if (computeMode$computeR) { # debugging
			.GlobalEnv$.Random.seed <- savedSeed # Roll back PRNG
		}

		test <- .computeColumnPmfAndNeighborhoods(computeMode$device$engine,
                                        parm$clust$C.m0, parm$clust$C.m.vec, 1e-3, 1e-5,
                                        parm$clust$G, parm$n2,
                                        parm$Y, parm$X,
                                        parm$clust$A.mt, parm$clust$s.mt,
                                        col.subset,
                                        parm$clust$C.m.vec, parm$p,
                                        parm$clust$phi.v, parm$tau, parm$tau_0, parm$tau_int,
                                        max.col.nbhd.size, parm$col.delta, TRUE)

    if (computeMode$computeR) { # debugging
      assertEqual(test$index, parm$clust$col.nbhd.k)
      assertEqual(test$neighbor, unlist(parm$clust$col.nbhd))
      assertEqual(test$neighborhoodMax, parm$clust$nbhd_max_dist, computeMode$tolerance)
    }

    # Convert from simple flat format to list of int vectors
    end <- test$offset[-1] - 1
    begin <- test$offset
    length(begin) <- length(begin) - 1

    parm$clust$col.nbhd <- lapply(1:length(begin),
                                  FUN = function(x) {
                                    test$neighbor[begin[x]:end[x]]
                                  })
    parm$clust$col.nbhd.k <- test$index
    parm$clust$nbhd_max_dist <- test$neighborhoodMax

  } # computeMode

  ## END

  parm
}


###########################################################
PDP_fn.gibbs <- function(l, k, parm, data, computeMode)
{		
    parm$k    <- k
    parm$I.k  <- I.k <- k	

	err <- 0
	err <- PDP_fn.consistency.check(parm)
	if (err > 0)
		{stop(paste("GIBBS - 0: failed consistency check: err=",err))
		}
	
	old.c.k <- unlist(parm$clust$c.v)[k]
	level.k <- unlist(parm$clust$auto$level)[k]
	###############
	
	parm$clust$C.m.vec.k <- parm$clust$C.m.vec.k.comp <- parm$clust$C.m.vec
		
	parm$clust$C.m.vec[[level.k]][old.c.k] <- parm$clust$C.m.vec[[level.k]][old.c.k] - 1
	

    #######################################################
	### emptied clusters are gone forever under Gibbs sampling
	#######################################################
	#till Lth level
	#X is full dimension. Treatment of X differ from A
	L.v         <- c()
    log.prior.v <- c()	
	xx        <- matrix(unlist(parm$X), parm$n2 )
	
	if(l >  1){	
		parm         <- fn.weight.h(parm,l)
		weight       <- parm$m.prob
	}else{
		weight       <- 1
	}
	
	wt.vec       <- rep(weight[1:l], as.integer(summary(parm$clust$C.m.vec)[,1])[1:l] + 1 )
	
	
	for(j in 1:l){
	
		x.mt         <- matrix(xx, ncol=1)

		n.vec.k.comp <- unlist(parm$clust$C.m.vec)[1:sum(as.integer(summary(parm$clust$C.m.vec)[,1])[1:l])]
		count.dim    <- sum(as.integer(summary(parm$clust$C.m.vec)[,1])[1:l])
		
		tmp          <- sapply(1:parm$clust$G[[j]], PDP_fn.log.lik, k, parm, data, j)

	    emptied.indx <- which(parm$clust$C.m.vec[[j]]==0)
	    new.G        <- parm$clust$G[[j]] - length(emptied.indx)
		
		if(length(emptied.indx) >0)
		{
			if (computeMode$computeR) {
				new.phi.mt     <- as.vector(parm$clust$A.mt[[j]][,-emptied.indx])
				ll             <- length( unique(new.phi.mt) )	
				phi    	       <- unique(as.vector(parm$clust$A.mt[[j]]))
				emptied.s.indx <- setdiff(which(phi %in% phi) , which( phi %in% new.phi.mt ))			
    	  
				new.n.vec <- array(,length(phi))
				for (pp in 1:length(phi) ) {
					new.n.vec[pp] <- sum(new.phi.mt==phi[pp]) # HOT
				}
			}
				new.K  <- ll
		}

		if (length(emptied.indx) ==0)
		{
			new.phi.mt <- as.vector(parm$clust$A.mt[[j]])
			ll         <- length(unique(new.phi.mt))
			phi    	   <- unique( as.vector(parm$clust$A.mt[[j]]) )
			emptied.s.indx <- setdiff(which(phi %in% phi) , which( phi %in% new.phi.mt ))
			new.K    <- ll
			new.n.vec <- array(,length(phi))
			
			for (pp in 1:length(phi) ) {
				new.n.vec[pp] <- length(which(new.phi.mt==phi[pp] )) # HOT
			}
		}
		## generate auxilliary P vector
		unq.K     <- length(phi)
		tmp.M     <- rep(parm$clust$M/new.K, unq.K)
		tmp.alpha <- tmp.M+new.n.vec
		tmp.alpha[emptied.s.indx] <- 0
		P.aux     <- rgamma(unq.K,c(tmp.alpha),1)
		P.aux     <- P.aux/sum(P.aux)

		## marginal likelihood of new cluster
		marg.log.lik.v <- array(,length(x.mt))
		sd  <- parm$tau[[j]]
	
		for (tt in 1:length(x.mt))
		{
			tmp.log.lik.v <- dnorm(x.mt[tt],mean=phi, sd=sd,log=TRUE) # HOT 3
			tmp.lik.v     <- exp(tmp.log.lik.v)
			tmp.marg.v    <- tmp.lik.v*P.aux
		
			marg.log.lik.v[tt] <- log(sum(tmp.marg.v))
		}
    
			marg.log.lik   <- sum(marg.log.lik.v)
	        L.v            <- c(L.v, tmp, marg.log.lik)
	        tmp.prior.v    <- array(NA, (1+parm$clust$G[[j]]))
				
			if (length(emptied.indx) >0)
			{
				tmp.prior.v[-(emptied.indx)] <- log(c((parm$clust$C.m.vec[[j]][-emptied.indx]-parm$d[[j]]), (parm$b1+new.G*parm$d[[j]])))
				tmp.prior.v[emptied.indx] <- -Inf
			}

			if (length(emptied.indx) ==0)
			{	tmp.prior.v <- log(c((parm$clust$C.m.vec[[j]]-parm$d[[j]]), (parm$b1+new.G*parm$d[[j]])))
			}
				log.prior.v <- c(log.prior.v, tmp.prior.v)			
    }			
			
		tmp2 <- log.prior.v + L.v + log(wt.vec)
		maxx <- max(tmp2)
		tmp2 <- tmp2 - maxx

		tmp2 <- exp(tmp2)

		parm$clust$post.k <- tmp2
		parm$clust$post.k <- parm$clust$post.k / sum(parm$clust$post.k)

	########################################################################
	# store current state
	old.parm <- parm
	########################################################################
	sample.n  <- sum(parm$clust$G[1:l]) + l
	new.c.k   <- sample(1:sample.n, size=1, replace=TRUE, prob=parm$clust$post.k)
	
	app.c    <- sort(cumsum(parm$clust$G + 1) )
	new.flag <- sum(new.c.k == app.c)
	
	new.level.c.k  <- which( sort(c(cumsum(parm$clust$G[1:l] + 1), new.c.k) ) %in% new.c.k )[1]
	
	if(new.level.c.k == 1){
			new.c.k  <- new.c.k
		}else{ 
			new.c.k  <- new.c.k - cumsum(parm$clust$G + 1)[new.level.c.k-1]
	}
	
	g.k  <- (parm$k -1)%/%parm$p + 1
	p.k  <- (parm$k -1)%%parm$p + 1
	
	parm$clust$c.v[[g.k]][p.k] 		<- new.c.k
	parm$clust$auto$level[[g.k]][p.k] <- new.level.c.k	
	
	
	#######################
    if (!new.flag)
		{
		  parm$clust$C.m.vec[[new.level.c.k]][new.c.k] 	<- parm$clust$C.m.vec[[new.level.c.k]][new.c.k] + 1
	    }

	if (new.flag)
	{
		j <- new.level.c.k
		###generate the latent vector first, condition on the single kth column
		cand.s.v.k <- cand.phi.v.k <- array(,parm$n2)
		sd <- parm$tau[[j]]

		phi.mt 		<- as.vector(parm$clust$A.mt[[j]])
		phi      	<- unique(phi.mt)
    
		for (tt in 1:length(x.mt))
		{
			tmp.log.lik.v <- dnorm(x.mt[tt],mean=phi, sd=sd,log=TRUE) # HOT 3
			tmp.lik.v   <- exp(tmp.log.lik.v)
			tmp.prob.v <- tmp.lik.v*P.aux
		
			#Numerical Stability
			tmp.prob.v[tmp.prob.v < 10^-10]  <- 10^-10
			prob.gen.v                       <- tmp.prob.v/sum(tmp.prob.v)
			cand.phi.v.k[tt]                 <- phi[sample(1:length(phi), size=1, replace=TRUE, prob=prob.gen.v)] # HOT
			cand.s.v.k[tt]                   <- parm$clust$s.v[[j]][which(phi.mt %in% cand.phi.v.k[tt])[1]]
	
		} # end for loop

  ##################
   parm$clust$G[[j]]          <- parm$clust$G[[j]] + 1
   parm$clust$C.m.vec[[j]]    <- c(parm$clust$C.m.vec[[j]], 1)
   
   parm$clust$s.v[[j]]        <- c(parm$clust$s.v[[j]], cand.s.v.k)
   parm$clust$s.mt[[j]]       <- cbind(parm$clust$s.mt[[j]], cand.s.v.k)   
	   
   tmp.a.v <- array(,parm$n2)
   tmp.a.v <- cand.phi.v.k
   parm$clust$A.mt[[j]] <- cbind(parm$clust$A.mt[[j]], tmp.a.v) # HOT
   parm$clust$B.mt[[j]] <- cbind(parm$clust$B.mt[[j]], tmp.a.v) # HOT

	if (parm$tBB_flag)
	{
		if (computeMode$computeR) {
		  parm$clust$tBB.mt[[j]] <- t(parm$clust$B.mt[[j]]) %*% parm$clust$B.mt[[j]] # HOT
		} else {
		  parm$clust$tBB.mt <- .fastXtX(parm$clust$B.mt)
		}
	}

  } # end  if (new.flag)


	list(parm, new.flag)
}

###########################################################
#I need to take care of empty clusters in an epoch
###########################################################
PDP_fn.fast_col <- function(l, cc, parm, data, computeMode)
{
   p <- parm$p
   col.subset  <- which(unlist(parm$clust$auto$level) == l)
   
   k   <- parm$k    <- parm$clust$col.nbhd.k[[l]][[cc]]
   I.k <- parm$I.k  <- parm$clust$col.nbhd[[l]][[cc]]

   err <- PDP_fn.consistency.check(parm)

   if (err > 0)
   {
		stop(paste("FAST - 0: failed consistency check: err=",err))
   }
   
  #initialize
  cand.phi.v.k <- cand.s.v.k <- list()
  
  #store so that we can revert to this state if MH propsal is rejected
  init.cc.parm  <- parm

  old.c.k       <- old.level.c.k <- new.level.c.k <- rep(NA, length(parm$I.k))
  old.c.k       <- unlist(parm$clust$c.v)[I.k]
  old.level.c.k <- level.k <- unlist(parm$clust$auto$level)[I.k]
  
  old.c.v       <- unlist(parm$clust$c.v)
  old.level.c.v <- unlist(parm$clust$auto$level)
  ###############

  parm$clust$C.m.vec.k.comp <- parm$clust$C.m.vec  

  for(i in 1:length(I.k) ){
		g.k  <- old.c.k[i]
		p.k  <- old.level.c.k[i]
		sum.ind  <- sum(old.c.k == g.k & old.level.c.k == p.k)
		parm$clust$C.m.vec.k.comp[[p.k]][g.k] <- parm$clust$C.m.vec[[p.k]][g.k] - sum.ind  
    }
  
	xx    <- matrix(unlist(parm$X), parm$n2)
	x.mt  <- matrix(xx[,k], parm$n2)
	
	L.v  <- log.prior.v <- c()
	cand.s.v.k <- cand.phi.v.k <- list()
	new.level.c.k <- c(NA, length(I.k))

	#till Lth level
	if(l > 1){
		parm         <- fn.weight.h(parm,l)
		weight       <- parm$m.prob
		wt.vec       <- rep(weight[1:l], as.integer(summary(parm$clust$C.m.vec)[,1])[1:l] + 1  )
		
	}else{
		weight       <- 1
		wt.vec       <- rep(weight[1:l], as.integer(summary(parm$clust$C.m.vec)[,1])[1:l] + 1  )
	}
	
	for(j in 1:l ){
	
		tmp          <- sapply(1:parm$clust$G[[j]], PDP_fn.log.lik, k, parm, data , j)
		emptied.indx <- which(parm$clust$C.m.vec.k.comp[[j]]==0)
		new.G 		 <- parm$clust$G[[j]] - length(emptied.indx)
		
		##Checks whether an epoch is empty
		full.empty.indx <- parm$clust$G[[j]]==0

		if (length(emptied.indx) >0 & !full.empty.indx)
		{
			if (computeMode$computeR) {
				new.phi.mt <- as.vector(parm$clust$A.mt[[j]][,-emptied.indx])
				ll         <- length( unique(new.phi.mt) )
				phi    	   <- unique(as.vector(parm$clust$A.mt[[j]]))
				emptied.s.indx <- setdiff(which(phi %in% phi) , which( phi %in% new.phi.mt ))	
				new.n.vec      <- array(,length(phi))
			
				for (pp in 1:length(phi) ) {
					new.n.vec[pp] <- sum(new.phi.mt==phi[pp]) # HOT
				}
			}
		
			new.K  <- ll
		}
		
		#The entire epoch is empty
		if(full.empty.indx){

			new.K <- ll <- num.gen <- 5

			new.n.vec  <- rmultinom(1, parm$n2, prob=c(rep(1/num.gen,num.gen)) )
			
			phi <- new.phi.mt <- array(,num.gen)
			for (tt in 1:num.gen)
			{
				phi[tt] <- new.phi.mt[tt] <- element_fn.gen.phi(parm, Y=NULL, lik.sd=NULL)
			}
			emptied.s.indx <-c()
		}	

		if(length(emptied.indx) ==0 &!full.empty.indx)
		{
			new.phi.mt     <- as.vector(parm$clust$A.mt[[j]])
			ll             <- length(unique(new.phi.mt))
			phi    	       <- unique(as.vector(parm$clust$A.mt[[j]]))
			emptied.s.indx <- setdiff(which(phi %in% phi) , which( phi %in% new.phi.mt ))
			new.K          <- ll
			new.n.vec      <- array(,length(phi))
			for (pp in 1:length(phi) ) {
				new.n.vec[pp] <- sum(new.phi.mt==phi[pp]) # HOT
			}	
		}
		
		## generate auxilliary P vector
		unq.K <- length(phi)
		tmp.M <- rep(parm$clust$M/new.K, unq.K)
		tmp.alpha <- tmp.M+new.n.vec
		tmp.alpha[emptied.s.indx] <- 0
		P.aux <- rgamma(unq.K,c(tmp.alpha),1)
		P.aux <- P.aux/sum(P.aux)

	# START
	if (computeMode$computeR) {
		if (computeMode$computeC) { # debugging
			savedSeed <- .GlobalEnv$.Random.seed # For debugging purposed only
		}
    
	    ## marginal likelihood of new cluster
		marg.log.lik.v <- array(,length(x.mt))
		cand.s.v.k[[j]] <- cand.phi.v.k[[j]] <- array(,length(x.mt))
		sd  <- parm$tau[[j]]
		
		for (tt in 1:length(x.mt))
		{
			tmp.log.lik.v <- dnorm(x.mt[tt],mean=phi, sd=sd,log=TRUE) # HOT 3
			tmp.lik.v     <- exp(tmp.log.lik.v)
			tmp.prob.v 	  <- tmp.lik.v*P.aux
				
			marg.log.lik.v[tt] 				<- log(sum(tmp.prob.v))
			prob.gen.v  					<- tmp.prob.v/sum(tmp.prob.v)
			cand.phi.v.k[[j]][tt]			<- phi[sample(1:length(phi), size=1, replace=TRUE, prob=prob.gen.v)] # HOT
			cand.s.v.k[[j]][tt]  		    <- parm$clust$s.v[[j]][which(phi == cand.phi.v.k[[j]][tt])[1]]
		} # end for loop

		marg.log.lik           <- sum(marg.log.lik.v)
  }

	L.v <- c(L.v, tmp, marg.log.lik)
  
	tmp.prior.v <- array(NA, (1+parm$clust$G[[j]]))
	spread.mass <- (parm$b1+new.G*parm$d[[j]])/(1+length(emptied.indx))

	if(length(emptied.indx) >0 & !full.empty.indx)
	{
		
		tmp.prior.v[-(emptied.indx)] <- log(c( (parm$clust$C.m.vec[[j]][-emptied.indx]-parm$d[[j]]), spread.mass))
		tmp.prior.v[emptied.indx]    <- log(spread.mass)
	}

	if (length(emptied.indx) ==0 & !full.empty.indx)
	{
		tmp.prior.v  <- log(c((parm$clust$C.m.vec[[j]] - parm$d[[j]]), spread.mass))
	}
	
	if(full.empty.indx){
		tmp.prior.v  <- log(spread.mass)
	}
	log.prior.v <- c(log.prior.v, tmp.prior.v) 	
   }#end big loop
 
	tmp2 <- log.prior.v + L.v + log(wt.vec)
	maxx <- max(tmp2)
	tmp2 <- tmp2 - maxx

	tmp2 <- exp(tmp2)

	parm$clust$post.k <- tmp2
	parm$clust$post.k <- parm$clust$post.k / sum(parm$clust$post.k)

   ########################################################################
   # store current state
   old.parm <- parm
   ########################################################################
   #sample.n <- sum(as.integer(summary(parm$clust$C.m.vec)[,1])[1:l])+l
   sample.n  <- sum(parm$clust$G[1:l]) + l
   new  	 <- new.c.k  <- sample(1:sample.n, size= length(I.k), replace=TRUE, prob=parm$clust$post.k)
   
   new.level.c.k <- rep(NA, length(I.k) )
   
   for(i in 1:length(I.k) ){
		
		new.level.c.k[i]  <- which( sort(c(cumsum(parm$clust$G + 1), new.c.k[i]) ) %in% new.c.k[i] )[1]
		
		if(new.level.c.k[i] == 1){
			new.c.k[i] <- new.c.k[i]
		}else{
			new.c.k[i] <- new.c.k[i] - cumsum(parm$clust$G + 1)[new.level.c.k[i]-1]
		}
		
		g.k  <- (parm$I.k[i] -1)%/%parm$p + 1
		p.k  <- (parm$I.k[i] -1)%%parm$p + 1

		parm$clust$c.v[[g.k]][p.k]        <- new.c.k[i]
		parm$clust$auto$level[[g.k]][p.k] <- new.level.c.k[i]	
	}
	
	tmp.parm <- parm
	
	#######################
	# Incremental Updates
	#########################
	#This patch was wrong. Updated #11/8
	for(j in 1:length(unique(new.level.c.k)) ){
		
		level.k <- unique(new.level.c.k)[j]
		ind     <- which(new.level.c.k == level.k)
		c.k.v   <- unique(new.c.k[ind])
		nn.v    <- unique(new[ind])
		
		for( i in 1:length(c.k.v) ){
			
				c.k <- c.k.v[i]
				length.ind 	<- length(which(new.c.k == c.k & new.level.c.k == level.k))
				
				n.k <- nn.v[i]
				#This is needed to find new clusters	
				#parm$clust$C.m.vec.k.comp could be 0

				if( n.k %in% c( cumsum(tmp.parm$clust$G + 1) ) ){
			
					parm$clust$C.m.vec.k.comp[[ level.k ]] <- c(parm$clust$C.m.vec.k.comp[[ level.k ]], length.ind)
					parm$clust$G[[ level.k ]]  			   <- parm$clust$G[[ level.k ]] + 1
					parm$clust$s.v[[level.k]]  			   <- c(parm$clust$s.v[[level.k]], cand.s.v.k[[level.k]] )
						
					parm$clust$s.mt[[level.k]] <- cbind(parm$clust$s.mt[[level.k]], cand.s.v.k[[level.k]])
					tmp.a.v 				   <- array(,parm$n2)
					tmp.a.v 				   <- cand.phi.v.k[[level.k]]
      
					parm$clust$A.mt[[level.k]] <- cbind(parm$clust$A.mt[[level.k]], tmp.a.v) # HOT
					parm$clust$B.mt[[level.k]] <- cbind(parm$clust$B.mt[[level.k]], tmp.a.v)
			
				}else{
					parm$clust$C.m.vec.k.comp[[ level.k ]][ c.k ] <- parm$clust$C.m.vec.k.comp[[ level.k ]][ c.k ]+ length.ind
					#Rest of parameters are to updated later using C.m.vec
				}		
				
		}
	}
	
	parm$clust$C.m.vec <- parm$clust$C.m.vec.k.comp

	exit <- (sum( (new.c.k != old.c.k) | (new.level.c.k!= old.level.c.k))==0)
	flip <- TRUE
	new.flag <- FALSE

	if(!exit) # CONTINUE W/O EXITING FUNCTION
	{
  		new.prop  <- 0
		count.ind <- 0
		for(j in 1:l){
			for(gg in 1:old.parm$clust$G[[j]]){
				count.ind  <- count.ind + 1
				count.gg   <- sum( (new.c.k ==gg) & (new.level.c.k == j) )
			
				if(count.gg > 0 ){
					new.prop <- new.prop + log(parm$clust$post.k[count.ind])*count.gg
				}
			}
		}
    ##########################################
    ##########################################
    ##### Computing proposal prob of reverse move
    ##########################################
    ##########################################
	old.prop  <- 0
	count.ind <- 0
	for(j in 1:l){
		for(gg in 1:old.parm$clust$G[[j]]){
			count.ind               <- count.ind + 1
		    count.gg                <- sum( (old.c.k ==gg) & (old.level.c.k == j ) )
	
			if(count.gg > 0 ){
				old.prop <- old.prop + log(old.parm$clust$post.k[count.ind])*count.gg
			}
		}
	}
    rho.prop <- new.prop - old.prop
    #######################################################
    #######################################################
    ########## computing true log-ratio: 2015
    #######################################################
    #######################################################

    # formula on page 1 of 07/27/15 notes
	# need to write notes before coding
    # need to ensure there are no empty clusters in either
    # init.cc.parm or parm, otherwise likelihood formula
    # doesn't work (lgamma of negative values)

    tmp.new.parm <- parm
    indx.new <- parm$clust$C.m.vec[[l]] > 0
    tmp.new.parm$clust$G[[l]] <- sum(indx.new)
    tmp.new.parm$clust$C.m.vec[[l]] <- parm$clust$C.m.vec[[l]][indx.new]
    #
    tmp.old.parm <- init.cc.parm
    indx.old <- init.cc.parm$clust$C.m.vec[[l]] > 0
    tmp.old.parm$clust$G[[l]] <- sum(indx.old)
    tmp.old.parm$clust$C.m.vec[[l]] <- init.cc.parm$clust$C.m.vec[[l]][indx.old]
	
	
	d.val   <- parm$d[[l]] 
    rho.tru <- fn.d(d.val, tmp.new.parm ,l ) - fn.d(d.val, tmp.old.parm,l)

    new.log.lik <- 0
    xx    <- matrix( unlist(parm$X), parm$n2 )
	
	for(level in unique(new.level.c.k) ){
		for (gg in unique(new.c.k) )
		{   
			indx.gg <- new.c.k == gg & new.level.c.k == level
			
			if( sum(indx.gg) > 0 ){
				x_gg.mt <- matrix(xx[,I.k[indx.gg]], ncol=sum(indx.gg))
				new.log.lik <- new.log.lik + sum(PDP_fn.log.lik(gg, I.k[indx.gg], parm, data,level))
			}	
		}
	}	
    old.log.lik <- 0
	
	for(level in unique(old.level.c.k))
	{
		for (gg in unique(old.c.k) )
		{	
			indx.gg <- old.c.k == gg & old.level.c.k == level
			
			if( sum(indx.gg) > 0 ){
				x_gg.mt <- matrix(xx[,I.k[indx.gg]], ncol=sum(indx.gg))
				old.log.lik <- old.log.lik + sum(PDP_fn.log.lik(gg, I.k[indx.gg], old.parm, data,level))
			}
		}
	}

    rho.tru <- rho.tru + new.log.lik - old.log.lik
    ########## toss a coin #################
	prob <- exp(min((rho.tru-rho.prop),0))
	
    flip <-as.logical(rbinom(n=1,size=1,prob=prob))

	if (!flip) {
		parm <- init.cc.parm
	}else{
		
 	}


  } # end BIG if (!exit) loop

   list(parm, new.flag, exit, flip)
}	

#####################################

PDP_fn.drop <- function(parm, computeMode)
 	{
			
	##########################################
	## Drop empty clusters:
	## (i)  Move empty clusters to end by relabeling clusters
	## (ii) Set parm$clust$G equal to number of non-empty clusters
	## (ii) Retain only clusters  1,...,parm$clust$G
	#########################################
	C.m.vec <- a.mt <- s.mt    <- list(array(,parm$h))
		
	for(l in 1: parm$h){
		ind.l 	<- which(unlist(parm$clust$auto$level)==l)
		c.l   	<- unlist(parm$clust$c.v)[ind.l]
		unq.c   <- sort(unique(c.l))
		s.mt[[l]] <- parm$clust$s.mt[[l]][,unq.c]
		a.mt[[l]] <- parm$clust$A.mt[[l]][,unq.c]
		parm$clust$G[l] <- length(unq.c)	
		
			for(g in 1: length(unq.c)){
				C.m.vec[[l]][g] <- length(which(c.l == unq.c[g]))
			}	
	}

		parm$clust$s.mt <- s.mt
		parm$clust$A.mt <- a.mt
		parm$clust$C.m.vec <- C.m.vec
		
		unq.s <- sort(unique(parm$clust$s.mt[[l]]))
		unq.a <- unique(parm$clust$A.mt[[l]])
		phi.v <- rep(NA, length(unq.s))
		n.vec <- rep(0, length(unq.s))
		
		for(i in unq.s){
			ind 	 <- which(parm$clust$s.mt[[l]]==i)
			phi.v[i] <- unq.a[ind[1]]
			n.vec[i] <- length(ind)
		}
		
		parm$clust$phi.v[[l]] <- phi.v
		parm$clust$K[[l]]     <- length(unq.s)
		parm$clust$n.vec[[l]] <- n.vec
	

		s.mat <- matrix(unlist(parm$clust$s.mt),parm$n2)
		a.mat <- matrix(unlist(parm$clust$A.mt),parm$n2)
		
		s.new <- parm$clust$s.mt
		a.new <- parm$clust$A.mt
		
	for(l in 1: parm$h){
		ind.l 			<- which(unlist(parm$clust$auto$level)==l)
		c.l   			<- unlist(parm$clust$c.v)[ind.l]
		
		parm$clust$G[[l]] <- sum(parm$clust$C.m.vec[[l]] > 0)
		num.dropped 	  <- sum(parm$clust$C.m.vec[[l]] == 0)
		
		if (parm$clust$G[[l]] > 0)
		{
		
			if (num.dropped > 0)
			{
			
				for (rr in 1:num.dropped)
				{
				old.label <-  min(which(parm$clust$C.m.vec[[l]] ==0))
				new.label <-  max(which(parm$clust$C.m.vec[[l]] > 0))
	
				s.new
		
	}	
		
		
    for(l in 1:parm$h ){
		
		parm$clust$G[[l]] <- sum(parm$clust$C.m.vec[[l]] > 0)
		num.dropped 	  <- sum(parm$clust$C.m.vec[[l]] == 0)
		
		if (parm$clust$G[[l]] > 0)
		{
		
		if (num.dropped > 0)
		{
	
			for (rr in 1:num.dropped)
			{
				old.label <-  min(which(parm$clust$C.m.vec[[l]] ==0))
				new.label <-  max(which(parm$clust$C.m.vec[[l]] > 0))
				
				stopp     <-  max(which(parm$clust$C.m.vec[[l]] >0)) == parm$clust$G[[l]]
				if (stopp)
				{	break
				}
				parm <- PDP_fn.swap.clusters(parm, g1 = new.label, g2 = old.label, l, computeMode)
			}
		}

		##########

		keep <- 1:parm$clust$G[[l]]
		parm <- PDP_fn.clip.clusters(parm, keep, l)

	###########

	# parm$clust$K does not change (possibly some empty elementwise clusters)

		#parm$N[[l]] <- parm$n2 * parm$clust$G[[l]]
		#parm$clust$s.v[[l]] 	   <- as.vector(parm$clust$s.mt[[l]])
		#parm$clust$auto$level[[l]] <- as.vector(parm$clust$auto.mt[[l]])
		
		#parm$clust$n.vec <- array(,parm$clust$K)
		#for (ss in 1:parm$clust$K)
		#{parm$clust$n.vec[ss] <- sum(parm$clust$s.v==ss)  # HOT
		#}

     }
   }
   #Update sd
   #parm <- fn.equivsd(parm,data)	
   #parm <- fn.matrix.sd(parm,data)
  
	parm
	}


PDP_fn.orientation <- function(parm, cc_subset)
  {
  X.mt <- matrix(parm$X[,cc_subset], ncol=length(cc_subset))
  c.v <- parm$clust$c.v[cc_subset]
  orient.v <- parm$clust$orient.v[cc_subset]

  # manipulate PDP_fn.log.lik to get log-likelihoods separately for each sign
  tmp.parm <- parm
  tmp.parm$flip.sign=FALSE

  log_lik.mt <- array(, c(2, length(cc_subset)))

  for (gg in 0:parm$clust$G)
  {indx.gg <- which(c.v==gg)

    if (length(indx.gg)>0)
      {X_gg.mt <- matrix(X.mt[,indx.gg], ncol=length(indx.gg))
      log_lik.mt[1,indx.gg] <- PDP_fn.log.lik(gg, x.mt = X_gg.mt, tmp.parm)
      log_lik.mt[2,indx.gg] <- PDP_fn.log.lik(gg, x.mt = -X_gg.mt, tmp.parm)
      }
  }

  maxx.v <- apply(log_lik.mt, 2, max)

  log_lik.mt <- t(t(log_lik.mt) - maxx.v)
  lik.mt <- exp(log_lik.mt)


  # assuming equal prior prob to each sign

  for (tt in 1:length(cc_subset))
    {orient.v[tt] <- sample(c(-1,1),size=1,prob=lik.mt[,tt])
    }

  parm$clust$orient.v[cc_subset] <- orient.v

    parm
  }


fast_PDP_fn.main <- function(parm, data, col.frac.probes, prob.compute.col.nbhd, max.col.nbhd.size, computeMode)
{
   p <- parm$p

   parm$clust$col_post.prob.mt <- list( array(parm$h) )
   parm$clust$col.nbhd.k       <- list( array(parm$h) )
   parm$clust$col.nbhd         <- list( array(parm$h) )
   
   if(parm$standardize.X)
		{	
			parm <- fn.standardize_orient.X(parm)
		}

	##########################
	# compute delta-neighborhoods
	#########################

	# SG: prob.compute.col.nbhd is the probability of computing
	# the neighborhoods, and col.frac.probes is the fraction of neighborhoods updated

    col_flip <- as.logical(rbinom(n=1,size=1,prob=prob.compute.col.nbhd))
	
	parm$clust$row.nbhd    <- list( array(, parm$h ) )
	parm$clust$row.nbhd.k  <- list( array(, parm$h ) )
	parm$subset_nbhd.indx  <- list( array(, parm$h ) )
	
	parm <- PDP_fn.post.prob.and.delta(parm, data, max.col.nbhd.size, col.frac.probes, computeMode)
	
	parm0 <- parm
	
	for(l in 1:parm$h ){

		if(col.frac.probes < 1)
		{	num_nbhds <- max(1,round(col.frac.probes*length(parm$clust$col.nbhd.k[[l]])))
			parm$subset_nbhd.indx[[l]] <- sort(sample(1:length(parm$clust$col.nbhd.k[[l]]), size=num_nbhds))
		}

		if(col.frac.probes == 1)
		{	parm$subset_nbhd.indx[[l]] <- 1:length(parm$clust$col.nbhd.k[[l]])
		}

		new.flag.v <- NULL
		col.mh.flip.v <- col.mh.exit.v <- NULL

		for (cc in parm$subset_nbhd.indx[[l]])
			{	
				previous.parm <- parm
				parm$k   <- parm$clust$col.nbhd.k[[l]][[cc]]
				parm$I.k <- parm$clust$col.nbhd[[l]][[cc]]
				
				if(length(parm$clust$col.nbhd[[l]][[cc]])==1)
				{ 
					tmp <- PDP_fn.gibbs(l,k=parm$k, parm, data, computeMode)
					parm <- tmp[[1]]
					new.flag.v <- c(new.flag.v, tmp[[2]])
					
				}

				if (length(parm$clust$col.nbhd[[l]][[cc]])>1 )
				{
					tmp <- PDP_fn.fast_col(l,cc, parm, data, computeMode)
					parm <- tmp[[1]]
					new.flag.v <- c(new.flag.v, tmp[[2]])
					col.mh.exit.v <- c(col.mh.exit.v, tmp[[3]])
					col.mh.flip.v <- c(col.mh.flip.v, tmp[[4]])
					
				}
			} # end for loop
	
	}
		
		#############################
		## Dropping empty PDP level clusters
		## Realignment of summary statistics
		############################
		
		parm <- PDP_fn.drop(parm)
		
		#Consistency Check is redundant
		#parm2 <- parm
		#parm <- PDP_fn.drop(parm, computeMode)
		#
		#err <- PDP_fn.compact.consistency.check(parm)
		#if (err > 0)
		#{stop(paste("MAIN FUNCTION END: failed consistency check: err=",err))
		#}			
		#err <- PDP_fn.compact.consistency.check(parm)
	
		err <- PDP_fn.consistency.check(parm)
	
		if (err > 0)
		{	stop(paste("LOOP: failed consistency check: err=",err))
		}
		
		#parm$clust$col.new.flag <- mean(new.flag.v)
		
		# if(!is.null(col.mh.flip.v))
		# {	parm$clust$col.mh.flip <- mean(col.mh.flip.v)
			# parm$clust$col.mh.exit <- mean(col.mh.exit.v)
		# } else{parm$clust$col.mh.flip <- 1
			# parm$clust$col.mh.exit <- 1
		# }
		
		
	##########################################
	## Drop empty group clusters:
	## (i)  Move empty clusters to end by relabeling clusters
	## (ii) Set parm$clust$G equal to number of non-empty clusters
	## (ii) Retain only clusters  1,...,parm$clust$G
	#########################################

	##Cross-Cohort Movement
	cohort.check <- TRUE
	
	if(sum( unlist(parm$clust$auto$level) == unlist(parm0$clust$auto$level)) ){
		cohort.check <- FALSE
	}
	
	#parm <- element_fn.drop(parm,cohort.check)
	parm <- fn3.update.element.objects(parm , computeMode )

	
	err <- PDP_fn.compact.consistency.check(parm)
	err <- element_fn.consistency.check(parm, data, computeMode)
	
	if (err > 0)
		{stop(paste("MAIN FUNCTION END: failed consistency check: err=",err))
		}

	parm
	}
