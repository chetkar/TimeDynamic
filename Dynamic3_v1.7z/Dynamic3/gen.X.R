gen.X <- function(n, p, prop.data.type, prop.X.miss, true_parm ) {
	
	## Assigns Data Type 
	X.cont.ind  <- rmultinom(p,1,prop.data.type)
	data.type   <- c(seq(1,5,1))
	X.data.type <- data.type%*%X.cont.ind

	## Number of epochs
	h <- true_parm$h
	
	data <- NULL
	data$h <- h
	data$OX <- data$X <- list(array(,c(h) ) )
	
	#####Steps
	## Populate the data matrix at Time = t
	for(i in 1:h ){
		data$OX[[i]] <- data$X[[i]] <- matrix(, n, p) 
		##Step 1 Populate the Data Matrix
		for(xx in 1:p)
			{
				
				theta.v  <- true_parm$clust$theta.v[[i]][ ,xx]
				
				if(X.data.type[xx]== 1 ){
					x.v    <- pnorm(theta.v)	
					x.v    <- rbinom(n, 1, x.v)	 
				}	
			
				if(X.data.type[xx]== 2 ){
					x.v       <- rnorm(n, mean = theta.v, sd = true_parm$tau)
				}
			
				if(X.data.type[xx]== 3 ){
					N0       <- 3
					x.v     <- N0*exp(theta.v)
					x.v     <- rpois(n , x.v)
				}	
				
				if( X.data.type[xx] == 4){				
				# 4 categories
					true.cutoff <- c(-Inf, -1 , 0, 1, Inf )
					q  <- length(true.cutoff)
					true.cutoff <- matrix( rep(true.cutoff, length(theta.v) ), length(theta.v), q , byrow=TRUE)
					true.prob        <- matrix(NA, length(theta.v), q-1)
				
					for(i in 1:4){
						true.prob[,i] <- pnorm(true.cutoff[,i+1] - theta.v) - pnorm(true.cutoff[,i] - theta.v)
					}	
					x.v <- theta.v
					for(j in 1: length(theta.v) ){
						x.v[j] <-	which( rmultinom(1, 1 ,true.prob[j,]) == 1)
					}
				}
				
				#Proportion
				if(X.data.type[xx] == 5 ){
					bet    <- 2
					x.v    <- bet*exp(theta.v)	
					x.v	<- rbeta(n, x.v, bet) 
				}			
				data$X[[i]][,xx] <- as.vector(x.v)
		}
		
		#Saving data in OX
		data$OX[[i]]        <- data$X[[i]]
		data$data.type[[i]] <- X.data.type
		
	}
	
	## neighborhood taxicab distances for column clusters
	## this needs to be updates
	
	true_parm$clust$nbhd.matrix <- list(array(,c(true_parm$h) ) )
	
	for(l in 1:true_parm$h ){
		tmp.mat <- array(0,c(p,p))
		for (jj in 1:true_parm$clust$G[[l]])
		{indx.jj <- which(true_parm$clust$c.v[[l]]==jj)
		tmp.mat[indx.jj,indx.jj] <- 1
		}
		true_parm$clust$nbhd.matrix[[l]] <- tmp.mat
	}
	

    
	###########################################
	# missing X values
	###########################################
	#missing X values could be critical in theoretical proof
	#that the posterior estimate obtained despite missing values is
	#same as the one that with all the data
	
	for(i in 1:h){
		data$num.X.miss <- round(prop.X.miss*n*p)

		if (data$num.X.miss>0)
		  {data$X.missing.x <- sample(1:n,size=data$num.X.miss, replace=TRUE)
	  	   data$X.missing.y <- sample(1:p,size=data$num.X.miss, replace=TRUE)
		   }
	

   		# works even if some (data$X.missing.x,data$X.missing.y) are tied by chance

		for(cc in 1:data$num.X.miss)
		  {data$X[[i]][data$X.missing.x[cc],data$X.missing.y[cc]] <- NA
	  	  }

	}
	###########################################
	# random split of 100 X prop % missing
	###########################################

	n2 <- p
	n1 <- 0
	data$missing.indx <- NULL
	data$non.missing.indx <- 1:p

	data$K.max <- round(n/2)
	data$G.max <- round(n2/2)

	###########################################
	# dummy responses
	###########################################

	data$Y <- rep(0,n2)
	data$delta <- rep(0,n2)
	data$true <- NULL
	data$true$Y <- data$Y
	data$true$delta <- data$delta

	############

	true <- NULL
	true$a.R <- true_parm$clust$M
	true$b0 <- 2.2
	true$b1 <- true_parm$b1
	

	#########################################
	# generating the R- and C- clusters
	########################################

	true$shift <- 1e-4

	return(list(data = data, true = true,true_parm = true_parm))
}
