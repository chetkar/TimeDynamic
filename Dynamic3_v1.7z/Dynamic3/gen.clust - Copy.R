# The first step is to find individual clusters
# The second step is to find autoregressive clusters

#' @keywords internal
gen.auto.prob <- function(prob){

	h <- length(prob)
	
	auto.prob <- rep(NA,h)
	
	for(l in 1:h){
		
		
		if( h!=1 ){
			m <- h-1
			if(l==1){
				auto.prob[l] <- prod(1 - prob[1:m])
			}
			if(l == h){
				auto.prob[l] <- prob[m]
			}
		
			if(l != 1 & l !=h ){
				auto.prob[l] <- prob[l-1]*prod(1-prob[l:m])
			}
		
		}else{

			auto.prob[1] <- prob[1]
			}
	}
	
	auto.prob
}



gen.clust <- function(n, p, prob) {

	h <- length(prob)
	true_parm <- NULL
	true_parm$d <- NULL
	true_parm$clust <- NULL
	true_parm$clust$c.v <- list(array(,h))

	true_parm$b0 <- 2.2
	true_parm$b1 <- 20
	true_parm$clust$C.m.vec <- list(array(,h))
	true_parm$clust$G <- list(array(,h))
	true_parm$clust$n.vec <- list(array(,h))

	true_parm$h <- h
	true_parm$clust$s.v  <- list(array(,h))
	true_parm$clust$s.mt <- list(array(,dim=c(n,n,h) ) )
	true_parm$clust$auto$C.m.vec <- array(, dim=c(h,n) )
	true_parm$clust$auto$G <- array(, dim=c(h,n) )
	true_parm$clust$auto$C.m.vec[1,1] <- 1
	
	#True Allocation
	for(i in 1:h){
		true_parm$clust$C.m.vec[[i]]  <- 1
		true_parm$clust$G[[i]]        <- 1
		true_parm$clust$c.v[[i]]   <- 1
		true_parm$d[[i]]        <- 1/3
		
		}

	#Column Level Clustering	
	for( i in 1:h ){
	
				auto.prob <- gen.auto.prob(prob[1:i])

				for(x in 1:n){
				
					if(x==1 & i==1 ){
					
					}else{
					
						ind <- which(rmultinom(1,1,prob=auto.prob)==1)
						true_parm$clust$auto$C.m.vec[i,x] <- ind
						prob.v <- true_parm$clust$C.m.vec[[i]] - true_parm$d[[ind]]
						prob.v <- c(prob.v, (true_parm$b1 + true_parm$clust$G[[ind]]*true_parm$d[[ind]]))
						new.c <- sample(1:(true_parm$clust$G[[ind]]+1), size=1, prob=prob.v)
						
						#Does it not create a overwritng problem?
						true_parm$clust$c.v[[i]][x] <- new.c
						new.flag <- (new.c > true_parm$clust$G[[ind]])
					
					if (new.flag)
					{	true_parm$clust$G[[ind]] <- true_parm$clust$G[[ind]] + 1
						true_parm$clust$C.m.vec[[ind]] <- c(true_parm$clust$C.m.vec[[ind]], 1)
					}
	 
					if(!new.flag)
					{	true_parm$clust$C.m.vec[[ind]][new.c] <- true_parm$clust$C.m.vec[[ind]][new.c] + 1
						
					}	
			
					}
				}
			}
			
			##Taxicab distance needs an update	
			##neighborhood taxicab distances for column clusters
			tmp.mat <- list(array(0,c(h)) )
	
			for(i in 1:h){
				tmp.mat[[i]] <- matrix(0,n,n)
				for(jj in 1:true_parm$clust$G[[i]])
				{	indx.jj <- which(true_parm$clust$c.v[[i]]==jj)
					tmp.mat[[i]][indx.jj,indx.jj] <- 1
				}
				true_parm$clust$nbhd.matrix[[i]] <- tmp.mat[[i]]
			}
	
	###########################################################
	
	#Cell level Clustering
	for(i in 1:h){	
	
		true_parm$N[[i]] <- n*true_parm$clust$G[[i]]
		no   <- p*true_parm$clust$G[[i]]
		true_parm$clust$s.v[[i]] <- array(,no)
		true_parm$clust$s.v[[i]][1] <- 1
		true_parm$clust$n.vec[[i]] <- 1
		true_parm$clust$K[[i]] <- 1
		#The parameter M is constant
		true_parm$clust$M <- 11
	
	
	for (xx in 2:true_parm$N[[i]])
		{##prob.v <- c((true_parm$clust$n0+true_parm$clust$M0),true_parm$clust$n.vec)
	 	  prob.v <- c(true_parm$clust$n.vec[[i]])
	 	  prob.v <- c(prob.v, true_parm$clust$M)
	 	  new.s <- sample(1:(true_parm$clust$K[[i]]+1), size=1, prob=prob.v)
	 
	 	  true_parm$clust$s.v[[i]][xx] <- new.s
	 	  new.flag <- (new.s > true_parm$clust$K[[i]])
	 
	 
	 	if (new.flag)
		 {true_parm$clust$K[[i]] <- true_parm$clust$K[[i]] + 1
	  	  true_parm$clust$n.vec[[i]] <- c(true_parm$clust$n.vec[[i]], 1)
	 	 }
	
		 if ((!new.flag))
	 	{true_parm$clust$n.vec[[i]][new.s] <- true_parm$clust$n.vec[[i]][new.s] + 1
	 	 }
		}

	true_parm$clust$s.mt[[i]] <- matrix(true_parm$clust$s.v[[i]], ncol=n)

	###########

	true_parm$clust$mu2  <- 0
	true_parm$clust$tau2 <- 1
	
	true_parm$clust$phi.v[[i]] <- rnorm(n=true_parm$clust$K[[i]], mean=true_parm$clust$mu2, sd=true_parm$clust$tau2)

	}

	
	
	return (true_parm)
}
