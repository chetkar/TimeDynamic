#'@keywords internal
gen.auto.prob <- function(prob=c(0.25,0.25,0.25)){

	h <- length(prob) + 1
	auto.prob <- rep(NA,h)
	
	for(i in 1:h){
	
		if(i == 1 ){
			auto.prob[1] <- prod(1-prob[1:h-1])
		}
		
		if(i == h ){
			auto.prob[h] <- prob[h-1]
		}
		
		if(i !=1 & i!=h ){
			hh <- h-1
			auto.prob[i] <- prob[i-1]*prod(1-prob[i:hh])
		}
	
	}
	auto.prob
}


gen.clust <- function(n, p, prob=c(0.25,0.25,0.25)) {

	h <- length(prob) + 1
	
	true_parm <- NULL
	true_parm$prob <- prob
	true_parm$d <- NULL
	true_parm$clust <- NULL
	true_parm$clust$c.v <- list(array(,h))

	true_parm$b0 <- 2.2
	true_parm$b1 <- 20
	

	true_parm$clust$C.m.vec <- list(array(,h))
	true_parm$clust$G <- list(array(,h))
	true_parm$clust$n.vec <- list(array(,h))

	true_parm$h <- h
	true_parm$clust$s.v  <- list(array(,h))
	true_parm$clust$G    <- list(array(,h))
	true_parm$clust$s.mt <- list(array(,h) )
	true_parm$clust$prob       <- list(array(,h))
	
    #Maps columns to cluster levels
	true_parm$clust$auto$level <- list(array(,h))

	#Redundant Variables #is it?
	true_parm$clust$auto$C.m.vec <- array(, dim=c(h,p) )
	true_parm$clust$auto$G <- array(, dim=c(h,p) )
	true_parm$clust$auto$C.m.vec[1,] <- 1
	
	true_parm$clust$nbhd.matrix <- list(array(,c(true_parm$h) ) )
	
	#True Allocation
	for(i in 1:h){
		true_parm$clust$C.m.vec[[i]] <- 1
		true_parm$clust$G[[i]]       <- 1
		true_parm$clust$c.v[[i]]   	 <- 1
		true_parm$d[[i]]        	 <- 0
		true_parm$clust$auto$level[[i]]      <- 1
		}

	#Column Level Clustering	
	#First Iteration
	#Columns at the first epoch (level) are mapped into clusters at first epoch (level)
	i <- 1
	true_parm$clust$prob[[1]] <- 1
	
	for(xx in 2:p){
	
			prob.v <- true_parm$clust$C.m.vec[[i]] - true_parm$d[[i]]
			prob.v <- c(prob.v, (true_parm$b1 + true_parm$clust$G[[i]]*true_parm$d[[i]]))
			new.c  <- sample(1:(true_parm$clust$G[[i]]+1), size=1, prob=prob.v)
						
			true_parm$clust$c.v[[i]][xx]   <- new.c
			true_parm$clust$auto$level[[i]][xx] <- i
			
			new.flag <- (new.c > true_parm$clust$G[[i]])
					
				if (new.flag)
				{	true_parm$clust$G[[i]] <- true_parm$clust$G[[i]] + 1
					true_parm$clust$C.m.vec[[i]] <- c(true_parm$clust$C.m.vec[[i]], 1)
				}
	 
				if(!new.flag)
				{	true_parm$clust$C.m.vec[[i]][new.c] <- true_parm$clust$C.m.vec[[i]][new.c] + 1
				}	
		}
		
	for(i in 2:true_parm$h){
				print(true_parm$h)
		for(xx in 1:p){
		
				#I might have to consider prob carefully here.
			    #Step 2 Autoregressively Update the column clusters
			    clust.prob  <- gen.auto.prob(true_parm$prob[1:i-1])
				print(clust.prob)
				clust.alloc <- which(rmultinom(1,1,clust.prob )== 1)
				j <- clust.alloc	
				
				prob.v <- true_parm$clust$C.m.vec[[j]] - true_parm$d[[j]]
				prob.v <- c(prob.v, (true_parm$b1 + true_parm$clust$G[[j]]*true_parm$d[[j]]))
				new.c  <- sample(1:(true_parm$clust$G[[j]]+1), size=1, prob=prob.v)
				true_parm$clust$c.v[[i]][xx] <- new.c
				true_parm$clust$auto$level[[i]][xx] <- j
				
				new.flag <- (new.c > true_parm$clust$G[[j]])
					
				if (new.flag)
				{	true_parm$clust$G[[j]] <- true_parm$clust$G[[j]] + 1
					true_parm$clust$C.m.vec[[j]] <- c(true_parm$clust$C.m.vec[[j]], 1)
				}
	 
				if(!new.flag)
				{	true_parm$clust$C.m.vec[[j]][new.c] <- true_parm$clust$C.m.vec[[j]][new.c] + 1
				}
				
				}
				true_parm$clust$prob[[i]]<- clust.prob	
	}
	
	
	#Cell level Clustering
	for(i in 1:true_parm$h){
			
			true_parm$N[[i]] 			<- n*true_parm$clust$G[[i]]
			no   						<- n*true_parm$clust$G[[i]]
			true_parm$clust$s.v[[i]] 	<- array(,no)
			true_parm$clust$s.v[[i]][1] <- 1
			true_parm$clust$n.vec[[i]]  <- 1
			true_parm$clust$K[[i]] 		<- 1
			true_parm$clust$M 			<- 11
	
	
		for(xx in 2:true_parm$N[[i]])
			{ 
			prob.v <- c(true_parm$clust$n.vec[[i]])
			prob.v <- c(prob.v, true_parm$clust$M)
			new.s <- sample(1:(true_parm$clust$K[[i]]+1), size=1, prob=prob.v)
	 
			true_parm$clust$s.v[[i]][xx] <- new.s
			new.flag <- (new.s > true_parm$clust$K[[i]])
	 
	 
			if(new.flag)
			{	true_parm$clust$K[[i]] <- true_parm$clust$K[[i]] + 1
				true_parm$clust$n.vec[[i]] <- c(true_parm$clust$n.vec[[i]], 1)
			}
	
			if((!new.flag))
			{	true_parm$clust$n.vec[[i]][new.s] <- true_parm$clust$n.vec[[i]][new.s] + 1
			}
			}
		
		true_parm$clust$s.mt[[i]] <- matrix(true_parm$clust$s.v[[i]], nrow = n)	

	
	###########
	#Modeling the mean or variance in an autoregressive way is another problem
	#that needs to be dealt with.
	#For now, I won't deal with it.
	
	true_parm$clust$mu2[[i]]  <- 2*i
	true_parm$clust$tau2[[i]] <- .05
	
	true_parm$clust$phi.v[[i]] <- rnorm(n=true_parm$clust$K[[i]], mean=true_parm$clust$mu2, sd=true_parm$clust$tau2)
	
	}
	
	#Update theta
	true_parm$clust$theta  <- list( array(,true_parm$h) )

	for(i in 1:true_parm$h){
		true_parm$clust$theta.v[[i]] <- matrix(NA, n , p )
	
		for(xx in 1:p){
			level <- true_parm$clust$auto$level[[i]][xx]
			clust <- true_parm$clust$c.v[[i]][xx]
		
		    true_parm$clust$theta.v[[i]][,xx] <- true_parm$clust$phi.v[[level]][true_parm$clust$s.mt[[level]][,clust]]
			
			#true_parm$clust$theta.v[[i]][,xx] <- true_parm$clust$phi.v[[true_parm$clust$epoch[[i]][xx] ]][true_parm$clust$s.mt[[true_parm$clust$epoch[[i]][xx]]][, true_parm$clust$c.v[[i]][xx]]]
		}
	
	}
	

	
	
	return (true_parm)
}
