fn.prob <- function(parm){

 prob <- rep(NA, parm$h-1)
 
 for(i in 1:parm$h-1){
	
		ii <- i + 1
		sum.a <- 1
		sum.b <- 1
		for(l in ii:parm$h ){
            #Is this correct update?		
			sum.a <- sum.a + length( which( parm$clust$auto$level[[l]] == ii ) )
			sum.b <- sum.b + length( which( parm$clust$auto$level[[l]] < ii ) )
		}
		prob[i] <- rbeta( 1, sum.a, sum.b )	
}		
 
 parm$prob <- prob
 
 parm
}

fn.weight.h <- function(parm,h){
	
   #For now, we have to assume parm$prob	
   parm <- fn.prob(parm)
   
   if(is.null(parm$prob )){
		prob = rep( 1/parm$h, parm$h )
		parm$prob = prob[1:parm$h-1]
	}
	
   p      <- parm$prob[1:h-1]
   pp     <- c(1, p)
   
   m.prob <- rep(NA,h)
	
   for(l in 1: h){
  
		l0 <- l + 1
		if(l < h){
			m.prob[l] <- pp[l]*(prod(1 -pp[l0:h]))
		}else{
			m.prob[l] <- pp[l]
			}
   }
   
   # if(h > 1 ){
		# h0 <- h - 1
		# q  <- c(rev(cumprod(1 - rev(p[1:h0]) )),1)
		# qq <- c(1, p[1:h0])
		# m.prob <- q*qq
   
    # }else{
	
		# m.prob[1] <- 1 - p
		# m.prob[2] <- p
	# }
     
	parm$m.prob <- m.prob   
   
parm
}

fn.dmvnorm <- function(x, mean, sigma, inv.sigma, log=TRUE)
	{

	# Computes multivariate normal density function
	# a little faster than dmvnorm function of R!

	if (missing(inv.sigma))
		{inv.sigma <- solve(sigma)
		}

	logdet <- as.numeric(determinant(inv.sigma, logarithm=TRUE)$mod)
	r <- length(x)
	Q <- colSums(inv.sigma * (x-mean))
	Q <- sum(Q * (x-mean))

	val <- -r/2*log(2*pi) + logdet/2 - Q/2
	if (!log)
		{val <- exp(val)
		}

	val
	}


fn.quality.check <- function(parm)
	{err <- 0

	if (!is.null(parm$clust$col.nbhd))
		{#if (sum(unlist(lapply(parm$clust$col.nbhd, length))) != length(parm$col.subset.I))
			#{err <- 1
			#}
		}

	if (parm$tBB_flag)
	  {
	  if (sum(diag(parm$clust$tBB.mt) < 0) > 0)
		  {err <- 2
	    }
	  }

	if (ncol(parm$clust$A.mt) != parm$clust$G)
		{err <- 3
		}

	if (ncol(parm$clust$B.mt) != (parm$clust$G+1))
		{err <- 4
		}

	if ((sum(parm$clust$C.m.vec) + parm$clust$C.m0) != parm$p)
		{err <- 5
		}

	if (length(parm$clust$n.vec) != parm$clust$K)
		{err <- 6
		}

	if (length(parm$clust$phi.v) != parm$clust$K)
		{err <- 7
		}

	if ((sum(parm$clust$n.vec) + parm$clust$n0) != parm$N)
		{err <- 8
		}

	err
	}

######################

fn.init.clusters <- function(parm)
{
		
	parm$d <- list(array(,parm$h))	
	# Not Working for the discrete case
    n <- dim(parm$X[[1]])[1]
	p <- dim(parm$X[[1]])[2]
	
	c.v <- rep(NA, length(unlist(parm$clust$auto$level)) )
	X     <- matrix(unlist(parm$X), nrow=parm$n2)
	
	for(l in 1:parm$h ){
	
		ind.c <- which(unlist(parm$clust$auto$level) == l)
		
		X.mt  <- matrix(X[,ind.c],nrow=parm$n2)
		num.centers <- parm$G.new   	
	
		options(warn=0)
	
		tmp2 <- kmeans( t( X.mt ), iter.max=1000, centers=num.centers, nstart=2)
	
		options(warn=2)

		c.v[ind.c] <- tmp2$cluster
		
		parm$clust$G[[l]] <- length(tmp2$size)

		parm$clust$C.m.vec[[l]] <- array(,parm$clust$G[[l]])

		for (g in 1:parm$clust$G[[l]] )
			{
				#I.g <- (parm$clust$c.v[[l]]==g)
				I.g <- (c.v[ind.c]==g)
				parm$clust$C.m.vec[[l]][g] <- sum(I.g)
			}

		parm$d[[l]] <- 1/3
	}
	
	for(l in 1:parm$h ){
		start.ind <- (l-1)*parm$p + 1
		end.ind   <- l*parm$p
		parm$clust$c.v[[l]] <- c.v[start.ind : end.ind]
	}
	###########################

	# start from PDP model with d=0 (i.e DP)
	#parm$d <- 1/3


	parm
}


fn.eda <- function(parm, data, computeMode)
{
	parm 		<- fn.init.clusters(parm)
	parm$G.max  <- min(parm$p/2, round(parm$clust$G[[1]]))
	parm 		<- fn.poissonDP.hyperparm(data, parm, w=.01, max.d=1)
	parm$clust$K <- parm$N 		<- parm$Y <- parm$clust$A.mt <- list(array(,c(parm$h) ) )
	parm$clust$phi.v <- parm$clust$s.v <- parm$clust$s.mt <- parm$clust$n.vec <- list(array(,c(parm$h) ) )
	#parm$clust$auto$level <- list( array(, c(parm$h) ) )
	parm$clust$th.v <- parm$clust$theta.v <- list( array(, c(parm$h) ) )
	parm$tau <- parm$clust$B.mt <- list(array(,c(parm$h) ) )
	parm$clust$C.m.vec <- list(array(,c(parm$h) ) )
	
	X     <- matrix(unlist(parm$X), nrow=parm$n2)
	
	for(l in 1:parm$h ){
		
		parm$Y[[l]] <- matrix(NA, parm$n2 , parm$clust$G[[l]] )
		parm$clust$C.m.vec[[l]] <- array(,c(parm$clust$G[[l]]))
		for(g in 1:parm$clust$G[[l]])
		{
		 
		 I.g <- ( which( unlist(parm$clust$c.v)==g & unlist(parm$clust$auto$level)==l) )
		 parm$clust$C.m.vec[[l]][g] <- m.g <- length(I.g)
		 
		 
		 if (m.g > 1)
			{
				X.mt  <- X[,I.g]
				x.g.v <- rowMeans(X.mt)
			
			}else{
				x.g.v <- X[,I.g]
			}
		
		 parm$Y[[l]][,g] <- as.vector(x.g.v)	
		
		}
		parm$clust$C.m0 <- parm$p - sum(parm$clust$C.m.vec[[l]])
		parm$clust$M    <- parm$a.R
		parm$clust$M0   <- .01*parm$clust$M
		parm$clust$K[[l]] <- data$K.max
		parm$clust$n.vec[[l]] <- array( NA, parm$clust$K[[l]] )
		########## Fix  DP hyperprior
		for(i in 1:parm$h){
			parm$clust$mu2[[i]]  <- 0
			parm$clust$tau2[[i]] <- 1
		}		
		#################################
		parm$g[[l]] <- rep(1:parm$clust$G[[l]],each=parm$n2)
		parm$N[[l]] <- parm$clust$G[[l]] * parm$n2
		parm$Y[[l]] <- as.vector(parm$Y[[l]])


		tmp <- tryCatch({
			iter.max <- ifelse((length(parm$Y[[l]]) > 1000), 10, 1000)
			 kmeans(parm$Y[[l]], iter.max = iter.max, centers = data$K.max, nstart = 10,
	         algorithm = "Hartigan-Wong" # TODO: MAcQueen works better?
			 )}, error = function(e) {
			 print("Kmeans did not converge ... using random assignment")
			 cluster <- sample(1:data$K.max, size = length(parm$Y[[l]]), replace = TRUE)
			 centers <- sapply(1:data$K.max, FUN = function(x) {
			 mean(parm$Y[[l]][which(cluster == x)])
			})
			
			list(cluster = cluster, centers = centers, size = data$K.max)
	   })

		parm$clust$s.v[[l]] <- tmp$cluster
		
		for(i in 1:parm$clust$K[[l]] ){
			parm$clust$n.vec[[l]][i] <- length( which(parm$clust$s.v[[l]] == i ) )
		}
		
		parm$clust$phi.v[[l]] <- as.vector(tmp$centers)
		parm$clust$th.v[[l]]  <- parm$clust$phi.v[[l]][parm$clust$s.v[[l]]]
		parm$clust$th.v[[l]]  <- matrix(parm$clust$th.v[[l]], nrow = parm$n2)
		
		parm$clust$theta.v[[l]] <- matrix(NA, nrow = parm$n2, ncol = parm$p)
		
		for(k in 1:parm$clust$G[[l]] ){
					ind <- parm$clust$c.v[[l]] == k 
					parm$clust$theta.v[[l]][,ind] <- parm$clust$th.v[[l]][,k]
		}
				

	
		parm$clust$s.mt[[l]] <- array(parm$clust$s.v[[l]], c(parm$n2,parm$clust$G[[l]]))

		parm$clust$A.mt[[l]] <- matrix(NA, parm$n2, parm$clust$G[[l]])   
		for(g in 1:parm$clust$G[[l]])
		{	parm$clust$A.mt[[l]][,g] <- parm$clust$phi.v[[l]][parm$clust$s.mt[[l]][,g]]
		}

		sum.resid.sq <- 0
	
		for(g in 1:parm$clust$G[[l]])
		{	flag.v <- parm$clust$c.v[[l]] == g & parm$data.type[[l]] ==2
			X.g.mt  <- parm$X[[l]][,flag.v]
			a.g.v   <- parm$clust$A.mt[[l]][,g]
			resid.g.mt <- X.g.mt - a.g.v
			sum.resid.sq <- sum.resid.sq + sum(resid.g.mt^2)
		}
	
		#parm$tau_int <- parm$tau <- sqrt(sum.resid.sq/parm$n2/parm$p)
		p1 <- sum(parm$data.type[[l]] == 2)
		parm$tau[[l]] <- sqrt(sum.resid.sq/parm$n2/p1)
		
		## objects of full size (based on all n2 cases)
		parm$clust$B.mt[[l]] <- cbind(rep(1,parm$n2), parm$clust$A.mt[[l]])
		
		if(parm$tBB_flag)
		{	parm$clust$tBB.mt[[l]] <- t(parm$clust$B.mt[[l]]) %*% parm$clust$B.mt[[l]]
		}
		
		parm <- fn.assign.priors(parm, data)
		}	
 parm
}



fn.gen.clust <- function(parm, data, max.row.nbhd.size, row.frac.probes, col.frac.probes, computeMode)
	{
  ###########################################
  # Missing X values
  ###########################################

   n <- dim(data$X[[1]])[1]
   p <- dim(data$X[[1]])[2]

    parm$X <- parm$X.missing.x <- parm$X.missing.y <- X.mt <- list(array(,c(parm$h) ) )
 
    for(l in 1:parm$h ){
   		X.mt[[l]]   	<- matrix(as.vector(data$X[[l]]),n, p)
		parm$X[[l]] 	<- X.mt[[l]]
	}	
	##################
	
	level <- rep(NA, parm$h*parm$p)
	prob  <- rep(1/parm$h, parm$h)
		
	for(l in 1:length(level)){
		level[l] <- which(rmultinom(1,1, prob)==1)
	}
		
	for(l in 1:parm$h){
		parm$clust$auto$level[[l]] <- rep(l,parm$p)
		parm$clust$auto$level[[l]][1:l] <- seq(1,l,1)

	}
	
	parm$G.new <- data$G.max 
	
	parm <- fn.eda(parm, data, computeMode)
	#parm <- fn.matrix.sd(parm,data)
	parm <- fn.hyperparameters(data, parm)

	#Initializing parm$bet
	parm$bet <- 2
	#parm <- fn.equivsd(parm,data)

	#parm <- fn.sample.mu(parm,data)
	parm <- fn.element.DP(data, parm, max.row.nbhd.size, row.frac.probes, computeMode)

	if (parm$tBB_flag)
	  {parm$clust$tBB.mt <- t(parm$clust$B.mt) %*% parm$clust$B.mt
	  }

	parm

	}

fn.init <- function(true, data, max.row.nbhd.size, row.frac.probes, col.frac.probes, true_parm, tBB_flag, standardize.X, flip.sign, computeMode = "R" )
	{
	parm <- NULL
	parm$h <- data$h
	parm$OX <- data$OX
	parm$prob <- data$prob
	parm$data.type <- data$data.type
	

	parm$tBB_flag <- tBB_flag
	parm$standardize.X <- standardize.X
	parm$flip.sign <- flip.sign

	parm$n2 <- dim(data$X[[1]])[1] # TODO Check
	parm$p <- dim(data$X[[1]])[2]  # TODO Check

	### ASSUMING POSITIVE ORIENTATION FOR ALL PDP CLUSTERS
	### IN INITIALIZATION
	parm$clust$orient.v <- rep(1,parm$p)

	# mass parameter of elementwise(s) groups
	# stored later in parm$clust$M
	parm$a.R <- true$a.R

	# mass paramater of columns
	parm$b1 <- true$b1

	# mass paramater of column-intercept cluster
	parm$b0 <- true$b0


	############################
	# For delta neighborhoods
	############################

	parm$col.delta <- .1

	# delta-neighborhood threshold for elements
	parm$row.delta <- .1

	#########################################
	# generating the R- and C- clusters
	########################################

	parm$shift <- true$shift
	parm <- fn.gen.clust(parm, data, max.row.nbhd.size, row.frac.probes, col.frac.probes, computeMode)
	
	parm <- fn.assign.priors(parm, data)

	parm

	}


fn.gen.missing.X <- function(data, parm)
{
  # impute missing X values
  #  X.mt <- data$X
  # Discrete Case		
    #Data <- fn.transform(parm,data)
    X.mt <- data$X
	
  if (parm$num.X.miss > 0)
  {
    for (cc in 1:parm$num.X.miss)
    {i.cc <- parm$X.missing.x[cc]
    j.cc <- parm$X.missing.y[cc]
    c.cc <- parm$clust$c.v[j.cc]
    if (c.cc != 0)
    {mean.cc <- parm$clust$A.mt[i.cc, c.cc]
    }
    if (c.cc == 0)
    {mean.cc <- 1
    }
    X.mt[i.cc, j.cc] <- rnorm(n=1, mean=mean.cc, sd=parm$tau)
    }
  }
  parm$X <- X.mt

  parm
}


fn.standardize_orient.X <- function(parm)
{

  ####
  ## STANDARDIZE X columns to unit variance and zero mean
  #####
  # Do only for columns with NA's
  # For other columns, it's just a one-time calculation at the beginning of MCMC

  if (parm$num.X.miss > 0)
    {tmp.X <- matrix(parm$X[,parm$X.missing.y],col=parm$num.X.miss)
    mean.v <- colMeans(tmp.X)
    sd.v <- apply(tmp.X, 2, sd)
    parm$X[,parm$X.missing.y] <- t((t(tmp.X) - mean.v)/sd.v)
   }

  ####
  ## ORIENT X
  ####

  parm$X <- t(t(parm$X) * parm$clust$orient.v)

  parm
}


fn.assign.priors <- function(parm, data)
	{

	parm$prior$tau <- NULL
	parm$prior$tau$alpha.tau <- 1e-2
	parm$prior$tau$beta.tau <- 1e-2

	parm$prior$tau$max <- sqrt(.75)*sd(as.vector(unlist(data$X)), na.rm=TRUE)
	parm$prior$tau$min <- 1e-10
	parm$prior$tau.sq$max <- parm$prior$tau$max^2
	parm$prior$tau.sq$min <- parm$prior$tau$min^2
	parm$prior$inv.tau.sq$max <- 1/parm$prior$tau.sq$min
	parm$prior$inv.tau.sq$min <- 1/parm$prior$tau.sq$max
	
	parm$prior$mu2$mean <- 0
	parm$prior$mu2$sd   <- 1
	parm$prior$tau2$alpha <- 1
	parm$prior$tau2$beta <- 1
	
	parm$sigma <- 1
	parm$clust$mu0 <- 0
	
	parm$prior$inv.sigma.sq$alpha <- 0.01
	parm$prior$inv.sigma.sq$beta  <- 0.01
 	
	parm
	}

########################################
#### This is for the continuous case ###
########################################

#This needs to be updated
fn.gen.tau  <- function(data, parm)
	{
	parm$tau <- list(array(,parm$h))

	sum.resid.sq <- 0
	count <- 0
	
	for(l in 1:parm$h ){

	
		for (g in 1:parm$clust$G[[l]] )
			{
			
			flag.v <- ( (parm$clust$c.v[[l]] == g & parm$data.type[[l]] == 2) | (parm$clust$c.v[[l]] == g & parm$data.type[[l]] == 6 ) ) 
		
				if(sum(flag.v)>0) 
				{
					X.g.mt <- parm$X[[l]][,flag.v]
					a.g.v <- parm$clust$A.mt[[l]][,g]
					resid.g.mt <- X.g.mt - a.g.v
					sum.resid.sq <- sum.resid.sq + sum(resid.g.mt^2)
					count <- count + parm$n2*sum(flag.v)
				}
			}
	
	
		shape <- parm$prior$tau$alpha + count/2
		rate  <- parm$prior$tau$beta + sum.resid.sq/2
		
		u.min <- pgamma(parm$prior$inv.tau.sq$min,shape=shape, rate=rate)
		u.max <- pgamma(parm$prior$inv.tau.sq$max,shape=shape, rate=rate)
		gen.u <- runif(n=1, min=u.min, max=u.max)

		parm$tau[[l]] <- 1/sqrt(qgamma(gen.u,shape=shape, rate=rate))
	
		if (round(u.min, digits = 5) == 1) # really close to 1
			{parm$tau[[l]]<- 1/sqrt(parm$prior$inv.tau.sq$min)
			}
		if (round(u.max, digits = 5) == 0) # really close to 0
			{parm$tau[[l]]<- 1/sqrt(parm$prior$inv.tau.sq$max)
			}
	
	}		
	
	
	parm
	}

########################################

########################################




fn.gen.tau_0  <- function(data, parm)
	{
	###################
	# update tau_0
	###################

    #if(!parm$discrete){
	
	sum.resid.sq <- 0
	count <- 0

	for (g in 1:parm$clust$G)
		{flag.v <- parm$clust$c.v == g
		z.g.v <- parm$clust$s.mt[,g] > 0

		if ((sum(1-z.g.v) > 0) & (sum(flag.v)>0))
			{X.g.mt <- parm$X[!z.g.v,flag.v]
			resid.g.mt <- X.g.mt
			sum.resid.sq <- sum.resid.sq + sum(resid.g.mt^2)
			count <- count + sum(1-z.g.v)*sum(flag.v)
			}
		}

	shape <- 1 + count/2
	rate <- 1 + sum.resid.sq/2

	# minimum possible value of parm$tau_0 = 1.5 * maximum possible value of parm$tau
	# maximum possible value of parm$tau_0 = 3 * sd(as.vector(data$X))
	u.min <- pgamma(1/9 / var(as.vector(data$X),na.rm=TRUE),shape=shape, rate=rate)
	u.max <- pgamma(1/1.5^2/parm$prior$tau.sq$min,shape=shape, rate=rate)
	gen.u <- runif(n=1, min=u.min, max=u.max)

      parm$tau_0 <- 1/sqrt(qgamma(gen.u,shape=shape, rate=rate))

    #}else{
	
	parm$tau_0 <- 1

	#}
	parm
	}

###############################################################################
# Updating Sd for each covariates 
###############################################################################

fn.disc.tau <- function(parm,data)
	{
	parm$clust$sd.v <- NULL
	
	# data$OX
  	n <- dim(data$OX)[1]
  	p <- dim(data$OX)[2]
	sd  <- matrix(NA,n,p)

	for (xx in 1:p ){
	s.v      <- parm$clust$s.mt[,parm$clust$c.v[xx]]
	theta.v  <- parm$clust$phi.v[s.v]
	
  	# Numerical Stability
  	log.p      <-  -log( 1 + exp(theta.v))  +  theta.v
  	log.var    <-	-2*log(1 + exp(theta.v))  +  theta.v

	sd[,xx]    <- sqrt(1/exp(log.var))
	
	}

	parm$clust$sd.v <- sd
	
parm
}




fn.hyperparameters <- function(data, parm)
	{

	# also updates update tau_int
	parm <- fn.gen.tau(data, parm)
	
	#parm <- fn.weight.h(parm,parm$h)
	
	parm <- fn.DP.hyperparameters(data,parm)

	#parm <- fn.gen.tau_0(data, parm)

	parm

	}


fn.funky <- function(s,t)
	{# on log scale
	lgamma(s+t) - lgamma(s)
	}

fn.d <- function(d.val, parm , l)
	{
	g   <- parm$clust$G[[l]]
	m.g <- parm$clust$C.m.vec[[l]]
	p   <- sum(parm$clust$C.m.vec[[l]])
	# formula in review paper by Lijoi and Prunster
	#log.lik <- sum(log(parm$b1 + seq(1:(g-1))*d.val)) - fn.funky((parm$b1+1), (parm$p-1)) + sum(fn.funky((1-d.val), (m.g-1)))

	log.lik <- sum(log(parm$b1 + seq(1:(g-1))*d.val)) - fn.funky((parm$b1+1), (p-1)) + sum(fn.funky((1-d.val), (m.g-1)))
	
	log.lik
	}

fn.poissonDP.hyperparm <- function(data, parm, w=.01, max.d)
	{

	## update parm$d conditional on parm$b1
	## 1/w must be an integer
	
	for(l in 1:parm$h ){
	
		d.v <- seq(0,max.d,by=w)
		len <- length(d.v)
		d.v <- d.v[-len]
		len <- len-1
	
		log.lik.v <- sapply(d.v, fn.d, parm , l)
		#putting 1/2 prior mass on 0 and remaining spread uniformly on positive points in d.v
		log.p.v <- log(.5) + c(0,  rep(-log(len-1),(len-1)))
		#log.p.v  <- c( rep( -log(len) , len ) )
	
		log.post.v <- log.lik.v + log.p.v
		log.post.v <- log.post.v - max(log.post.v)
		post.v <- exp(log.post.v)
		post.v <- post.v/sum(post.v)

		prop.d <- sample(d.v, size=1, prob=post.v)

		if(prop.d > 0)
		{	
			prop.d <- runif(n=1, min=(prop.d-w), max=(prop.d+w))
		}

		if(prop.d != parm$d[[l]])
		{
		# MH ratio for independent proposals and
		# prior same for all d (which is true if 0 wp .5 and \in (0,max.d) wp .5)

		log.ratio <- fn.d(d=prop.d, parm , l) - fn.d(d=parm$d[[l]], parm , l)
		prob <- min(1, exp(log.ratio))
		flip <- rbinom(n=1, size=1, prob=prob)
		if (flip==1)
			{parm$d[[l]] <- prop.d
			}
		}

	}
	
	parm

	}

#This needs attention
fn.DP.hyperparameters <- function(data,parm)
	{

	for(i in 1:parm$h ){
	
	
		# TO BE COMPLETED
		# Now generate parm$clust$mu0 & parm$clust$tau using parm$clust$phi.v
	
		post.mu.prec    <- length(parm$clust$phi.v[[i]])/parm$clust$tau2[[i]]^2 + 1/parm$prior$mu2$sd^2
		post.mu.mean	<- (1/post.mu.prec) * ( sum(parm$clust$phi.v[[i]])/parm$clust$tau2[[i]]^2 + parm$prior$mu2$mean/parm$prior$mu2$sd^2 )
		parm$clust$mu2[[i]]  <- rnorm(1,post.mu.mean,sqrt(1/post.mu.prec))
	
		#Updating tau^2
	
		post.sigma.shape <- parm$prior$inv.sigma.sq$alpha + length(parm$clust$phi.v[[i]])/2
		post.sigma.rate  <- parm$prior$inv.sigma.sq$beta + t( parm$clust$phi.v[[i]] -parm$clust$mu2[[i]])%*%(parm$clust$phi.v[[i]] -parm$clust$mu2[[i]])/2 
		parm$clust$tau2[[i]]   <- sqrt(1/rgamma(1,post.sigma.shape, scale = 1/post.sigma.rate))

		
	}
	
		
	parm

	}	


########################################

fn.iter <- function(data, parm, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm,
                    computeMode)
	{
		
	#parm0 <- parm	
	parm <- fast_PDP_fn.main(parm, data, col.frac.probes, prob.compute.col.nbhd, max.col.nbhd.size, computeMode)
	#parm1 <- parm
	parm <- fn.element.DP(data, parm, max.row.nbhd.size, row.frac.probes, computeMode)
	parm <- fn.poissonDP.hyperparm(data, parm, w=.01, max.d=1)
	parm <- fn.hyperparameters(data, parm)
	parm <- fn.prob(parm)		

	parm
	}


#####################################################################################################

fn.postBurnin <- function(text, All.Stuff, offset, n.reps, data, parm, dahl.flag, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm)
  {
  
  for (cc in 1:n.reps)
  {
  parm1 <- parm	
  parm <- fn.iter(data, parm, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm, computeMode)
  
  if(cc %% 10 ==0){
		print(c("REPS = ",cc,date(),"***********"))
	}
	
  
  for(l in 1:parm$h ){
	All.Stuff$G.v[[l]][cc+offset] <- parm$clust$G[[l]]
	All.Stuff$K.v[[l]][cc+offset] <- parm$clust$K[[l]]
	All.Stuff$tau.v[[l]][cc+offset] <- parm$tau[[l]]

	All.Stuff$tau2.v[cc+offset]   <- parm$clust$tau2
	All.Stuff$d.v[[l]][cc+offset] <- parm$d[[l]]
   }	
  #summarizing elementwise DP in "fn.groupwise.updates"
  #All.Stuff$row.flip.v[cc+offset]  <- parm$clust$row.flip

	#All.Stuff$col_new_clust.v[cc+offset]  <- parm$clust$col.new.flag
	#All.Stuff$col_flip.v[cc+offset]  <- parm$clust$col.mh.flip
	#All.Stuff$col_exit.v[cc+offset]  <- parm$clust$col.mh.exit
	#All.Stuff$nbhd_max[cc+offset] <- round(parm$clust$nbhd_max_dist, digits = 2)

  # least squares calculation
  parm = fn.Dahl(parm, All.Stuff, dahl.flag)
  All.Stuff$mean.taxicab.v[cc+offset] <- mean( unlist(true_parm$clust$nbhd.matrix) != unlist(parm$dahlDist.mt) )
  
  if (!is.finite(All.Stuff$mean.taxicab.v[cc+offset]))
  {stop("Nan")}
  
   if (!dahl.flag)
     {
	 for(l in 1:parm$h ){
		 All.Stuff$meanDahlDist.mt[[l]] = All.Stuff$meanDahlDist.mt[[l]] + parm$dahlDist.mt[[l]]
     }
	 }
  
  if (dahl.flag)
  {All.Stuff$runningMinDahlDist.v[cc]  <- parm$min_Dahl_dist
  All.Stuff$dahlDist.v[cc]  <- parm$Dahl_dist
  }

  if (cc %% 10 == 0)
    {print(paste(text, "REPS = ",cc,date(),"***********"))
    }
  
  } # END FOR LOOP
  
   if (!dahl.flag)
   {
	for(l in 1:parm$h ){
		All.Stuff$meanDahlDist.mt[[l]] = All.Stuff$meanDahlDist.mt[[l]]/n.reps
    } 
   }
  
  if (dahl.flag)
  {
  for(l in 1:parm$h ){
  All.Stuff$est_c.v[[l]]  <- parm$est_c.v[[l]]
  }
  All.Stuff$min_Dahl_dist = parm$min_Dahl_dist
  }
  
  tmp = list(parm, All.Stuff)
  names(tmp) = c("parm", "All.Stuff")
  
  tmp
  }

##############################################################################

fn.mcmc <- function(text, true, data, n.burn, n.reps, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm, dahl.flag=FALSE,
                    standardize.X=FALSE, flip.sign =FALSE, tBB_flag=FALSE, computeMode ="R")
	{
	# initialize
	parm <- fn.init(true, data, max.row.nbhd.size, row.frac.probes, col.frac.probes, true_parm, tBB_flag, standardize.X, flip.sign, computeMode)
	init.parm <- parm

	text="BURNIN..."
	
	for (cc in 1:n.burn)
		{
		
		parm <- fn.iter(data, parm, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm, computeMode)

			if (cc %% 100 == 0)
			{	
				print(paste("REPS = ",cc,date(),"***********"))
			}
		}

	##########################################
	## DEFINE OBJECTS
	##########################################
	All.Stuff <- NULL
	#
	All.Stuff$tau_0.v <-  All.Stuff$tau_int.v <- array(,2*n.reps)
	All.Stuff$tau.v <- All.Stuff$d.v <- All.Stuff$G.v <- All.Stuff$K.v <- list(array(,parm$h))
	All.Stuff$meanDahlDist.mt <- list(array(,c(parm$h)))
	
	for(l in 1:parm$h ){
	
		All.Stuff$tau.v[[l]] <-All.Stuff$d.v[[l]] <- All.Stuff$G.v[[l]] <- All.Stuff$K.v[[l]] <- array(,2*n.reps)
		All.Stuff$meanDahlDist.mt[[l]] <-array(0,c(parm$p,parm$p))		
	}
	
	All.Stuff$row.flip.v  <- array(,2*n.reps)
	All.Stuff$nbhd_max <- All.Stuff$col_new_clust.v  <- All.Stuff$col_exit.v <- All.Stuff$col_flip.v  <- array(,2*n.reps)

	All.Stuff$mean.taxicab.v  <- array(,2*n.reps)
	
	# this is only for n.reps (runs 1 or 2)
	All.Stuff$runningMinDahlDist.v  <- All.Stuff$dahlDist.v  <- array(,n.reps)

	
	
	##########################################
	## POST-MCMC RUN 1
	##########################################
	
	text="POST--BURNIN RUN 1..."
	
	tmp = fn.postBurnin(text, All.Stuff, offset=0, n.reps, data, parm, dahl.flag=FALSE, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm)
  	parm = tmp$parm
  	All.Stuff = tmp$All.Stuff

	

	
	##########################################
	## POST-MCMC RUN 2: ALSO COMPUTE LEAST SQUARES ALLOCATION
	##########################################
	
	text="RUN 2: DAHL..."
	
	parm$min_Dahl_dist = parm$p^2
	
	tmp = fn.postBurnin(text, All.Stuff, offset=n.reps, n.reps, data, parm, dahl.flag=TRUE, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm)
	parm = tmp$parm
	All.Stuff = tmp$All.Stuff
	
	#######################
	
	All.Stuff$parm <- parm
	All.Stuff$init.parm <- init.parm

	All.Stuff
	}