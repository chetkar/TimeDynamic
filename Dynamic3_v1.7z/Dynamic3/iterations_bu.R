# Transform mixed (bernoulli and continuous) data into continuous

fn.transform <- function(parm, data){

  discrete <- parm$discrete

  # data$OX
  n  <- dim(data$OX)[1]
  p  <- dim(data$OX)[2]
  TX <- matrix(NA,n,p)

 for( xx in 1:p) {	

	theta.v      <- parm$clust$A.mt[,parm$clust$c.v[xx]]	

	if ( parm$col.ind[xx] == 0 )
  {
 
	#Check logit
	if(parm$discrete == "logit" ) 
	{  
  		log.var    <-  -2*log(1 + exp(theta.v))  +  theta.v
        TX[,xx]    <-  exp(-log.var)*(data$OX[,xx]) - 1 - exp(theta.v)
  		TX[,xx]    <-  theta.v + TX[,xx]
	
	}
		
	 #Check Probit	
  
	if(parm$discrete == "probit")
	{

	ind0      <- which(data$OX[,xx] == 0)	
	ind1      <- which(data$OX[,xx] == 1)
	

	TX[ind0,xx] 	  <- rtnorm( length(ind0) ,mean = theta.v[ind0] , sd = 1, upper =0)
	TX[ind1,xx] 	  <- rtnorm( length(ind1) ,mean = theta.v[ind1] , sd = 1, lower =0)	
	
	} 
	
	if(parm$discrete == "poisson")
	{
		
	TX[,xx] 	  	  <- theta.v + exp(-theta.v)*(data$OX[,xx] ) - 1


	} 
	

 }else{
 
    TX[,xx] <- data$OX[,xx]
 }
   	
}# endif transformation
data$X <- TX

data	
}

#Called up by elementwise_DP.functions.R
fn.matrix.sd <- function(parm,data){

 n <- nrow(parm$X)
 p <- ncol(parm$X)
 parm$clust$sd.matrix.mt <- NULL
 parm$clust$sd.matrix.mt <- matrix(0,n,p)
 parm$clust$s.full.mt   <- matrix(0,n,p)
 
 for(l in 1:p ){

	theta.v <- parm$clust$A.mt[,parm$clust$c.v[l] ]
	s.v     <- parm$clust$s.mt[,parm$clust$c.v[l]]
	parm$clust$s.full.mt[,l] <- s.v
  
    
	if ( parm$col.ind[l]== 0){

 	if ( parm$discrete == "logit" ) {
 
 		sd.v.m  <- -2*log( 1 + exp(theta.v) ) + theta.v
        sd.v.m  <- sqrt( 1/exp(sd.v.m) )
		
 	} # end logit
    	   

	if ( parm$discrete == "probit" ) {
 
 		 sd.v.m  <- rep(1,n)
		
  	} # end probit
	
	if ( parm$discrete == "poisson" ) {
 
 		 sd.v.m  <- sqrt( exp(-theta.v) )
		
  	} # end probit

	} else{
	
	sd.v.m <- rep(parm$tau,n)
	
	}

  parm$clust$sd.matrix.mt[,l] <- sd.v.m

 }# end forloop

 parm$clust$max.sd <- max(parm$clust$sdm.mt)
 parm$clust$min.sd <- min(parm$clust$sdm.mt)
 parm$clust$avg.sd <- mean(parm$clust$sdm.mt)
 
 parm 

}

# Called by PDP_fn.log.lik
fn.PDP.sd <- function(k, col.subset, parm,data){

 n <- nrow(parm$X)
 p1 <- length(col.subset)
 parm$clust$sd.sub.mt <- NULL
 parm$clust$sd.sub.mt <- matrix(NA,n,p1)

 theta.v <- parm$clust$A.mt[,k]
  i <- 0
 for(l in col.subset ){

	i <- i +1
	if ( parm$col.ind[l]== 0){

 	if ( parm$discrete == "logit" ) {
 
 		sd.v.m  <- -2*log( 1 + exp(theta.v) ) + theta.v
        sd.v.m  <- sqrt( 1/exp(sd.v.m) )
		
 	} # end logit
    	   

	if ( parm$discrete == "probit" ) {
 
 		 sd.v.m  <- rep(1,n)
		
  	} # end probit
	
	if ( parm$discrete == "poisson" ) {

	
 		 sd.v.m  <- sqrt( exp(-theta.v))
		
  	} # end probit

	} else{
	
	sd.v.m <- rep(parm$tau,n)
	
	}

  parm$clust$sd.sub.mt[,i] <- sd.v.m

 }# end forloop

 parm 
}


# Called by PDP_fn.log.lik
fn.equivsd <- function(parm,data){

 n <- nrow(parm$X)
 p <- ncol(parm$X)
 parm$clust$sdm.mt <- NULL
 parm$clust$sdm.mt <- matrix(NA,n,p)

  
 for(l in 1:p ){

	theta.v <- parm$clust$A.mt[,parm$clust$c.v[l]]

	if ( parm$col.ind[l]== 0){

 	if ( parm$discrete == "logit" ) {
 
 		sd.v.m  <- -2*log( 1 + exp(theta.v) ) + theta.v
        sd.v.m  <- sqrt( 1/exp(sd.v.m) )
		
 	} # end logit
    	   

	if ( parm$discrete == "probit" ) {
 
 		 sd.v.m  <- rep(1,n)
		
  	} # end probit
	
	if ( parm$discrete == "poisson" ) {

	
 		 sd.v.m  <- sqrt( exp(-theta.v) )
		
  	} # end probit

	} else{
	
	sd.v.m <- rep(parm$tau,n)
	
	}

  parm$clust$sdm.mt[,l] <- sd.v.m

 }# end forloop

 parm$clust$max.sd <- max(parm$clust$sdm.mt)
 parm$clust$min.sd <- min(parm$clust$sdm.mt)
 parm$clust$avg.sd <- mean(parm$clust$sdm.mt)
 
 parm 

}


fn.vectorPDP.sd <- function(k , parm, data){

	object <- NULL
	theta.v <- parm$clust$phi.v

	sd.v.m <- sd.v.c <- rep(NA,length(theta.v) )
		
	
	if ( sum(parm$col.ind[k]== 0) > 0){

 	if ( parm$discrete == "logit" ) {
 
 		sd.v.m  <- -2*log( 1 + exp(theta.v) ) + theta.v
        sd.v.m  <- sqrt( 1/exp(sd.v.m) )
		
 	} # end logit
    	   

	if ( parm$discrete == "probit" ) {
 
 		 sd.v.m  <- rep(1, length(theta.v) )
		
  	} # end probit
	
	if ( parm$discrete == "poisson" ) {
 
 		 sd.v.m  <- sqrt(exp(-theta.v))
		
  	} # end probit

	}
	
	if(sum(parm$col.ind[k]== 1) > 0){
	
	sd.v.c <- rep(parm$tau, length(theta.v))
	
	}


object[[1]]     <- sd.v.m
object[[2]]     <- sd.v.c

object
}

fn.vectorDP.sd <- function(tt , parm, data){

	object <- NULL

	gg <- (tt -tt%%parm$n2)/parm$n2 + 1
	#gg <- parm$clust$c.v[gg]
	
	theta.v <- parm$clust$phi.v
	
	if ( sum(parm$clust$c.v == gg & parm$col.ind== 0) > 0){

 	if ( parm$discrete == "logit" ) {
 
 		sd.v.m  <- -2*log( 1 + exp(theta.v) ) + theta.v
        sd.v.m  <- sqrt( 1/exp(sd.v.m) )
		
 	} # end logit
    	   

	if ( parm$discrete == "probit" ) {
 
 		 sd.v.m  <- rep(1, length(theta.v) )
		
  	} # end probit
	
	if ( parm$discrete == "poisson" ) {
 
 		 sd.v.m  <- sqrt(exp(-theta.v))
		
  	} # end probit

	}
	
	if(sum(parm$clust$c.v == gg & parm$col.ind== 1) > 0){
	
	sd.v.c <- rep(parm$tau, length(theta.v))
	
	}


object[[1]]     <- sd.v.m
object[[2]]     <- sd.v.c

object
}


fn.elementDP.sd <- function(tt, l , parm, data){

	object <- NULL

	gg <- (tt -1)%/%parm$n2 + 1
	#gg <- parm$clust$c.v[gg]
	
	theta.v <- parm$clust$phi.v[l]
	sd.v.m <- sd.v.c <- rep(NA,length(theta.v) )
	
	if ( sum(parm$clust$c.v ==gg & parm$col.ind ==0) > 0){

 	if ( parm$discrete == "logit" ) {
 
 		sd.v.m  <- -2*log( 1 + exp(theta.v) ) + theta.v
        sd.v.m  <- sqrt( 1/exp(sd.v.m) )
		
 	} # end logit
    	   

	if ( parm$discrete == "probit" ) {
 
 		 sd.v.m  <- rep(1, length(theta.v) )
		
  	} # end probit
	
	if ( parm$discrete == "poisson" ) {
 
 		 sd.v.m  <- sqrt( exp(-theta.v) )
		
  	} # end probit

	} 
	
	if ( sum(parm$clust$c.v ==gg & parm$col.ind ==1) > 0){

	sd.v.c <- rep(parm$tau, length(theta.v))
	
	}


object[[1]]     <- sd.v.m
object[[2]]     <- sd.v.c

object
}

#Called by Elementwise_DP.functions.R
fn.const <- function(tt, parm, data){

	object <- NULL

    gg   <- (tt -1)%/%parm$n2 + 1
	ind1 <- which(parm$clust$c.v==gg & parm$col.ind== 0 )
	ind2 <- which(parm$clust$c.v ==gg & parm$col.ind==1)
    l  	 <- tt%%parm$n2 + 1
	
	sd.v.m <- NA
	sd.v.c <- NA
	
	if ( length(ind1) > 0){
	 sd.v.m <- parm$clust$sdm.mt[l,ind1[1]]	
	}
	
	if(length(ind2) > 0){
	sd.v.c <- parm$clust$sdm.mt[l,ind2[1]]
	}
	
object[[1]]    <- sd.v.m
object[[2]]    <- sd.v.c

object
}





#This is not required
fn.split.nbhd <- function(k,parm)
{
subset <- NULL

g.k <- (k-1)%/%parm$n2 + 1
c.k <- which(parm$clust$c.v == g.k)

subset.k1 <- which(parm$clust$c.v == g.k & parm$clust$col.ind == 0)
subset.k2 <- which(parm$clust$c.v == g.k & parm$clust$col.ind == 1)

subset[[1]] <- subset.k1
subset[[2]] <- subset.k2

subset
}


fn.dmvnorm <- function(x, mean, sigma, inv.sigma, log=TRUE)
	{

	# Computes multivariate normal density function
	# a little faster than dmvnorm function of R!

	if (missing(inv.sigma))
		{inv.sigma <- solve(sigma)
		}

	logdet <- as.numeric(determinant(inv.sigma, logarithm=TRUE)$mod)
	r <- length(x)
	Q <- colSums(inv.sigma * (x-mean))
	Q <- sum(Q * (x-mean))

	val <- -r/2*log(2*pi) + logdet/2 - Q/2
	if (!log)
		{val <- exp(val)
		}

	val
	}



fn.quality.check <- function(parm)
	{err <- 0

	if (!is.null(parm$clust$col.nbhd))
		{#if (sum(unlist(lapply(parm$clust$col.nbhd, length))) != length(parm$col.subset.I))
			#{err <- 1
			#}
		}

	if (parm$tBB_flag)
	  {
	  if (sum(diag(parm$clust$tBB.mt) < 0) > 0)
		  {err <- 2
	    }
	  }

	if (ncol(parm$clust$A.mt) != parm$clust$G)
		{err <- 3
		}

	if (ncol(parm$clust$B.mt) != (parm$clust$G+1))
		{err <- 4
		}

	if ((sum(parm$clust$C.m.vec) + parm$clust$C.m0) != parm$p)
		{err <- 5
		}

	if (length(parm$clust$n.vec) != parm$clust$K)
		{err <- 6
		}

	if (length(parm$clust$phi.v) != parm$clust$K)
		{err <- 7
		}

	if ((sum(parm$clust$n.vec) + parm$clust$n0) != parm$N)
		{err <- 8
		}

	err
	}

######################

fn.init.clusters <- function(parm)
{
		
	# Not Working for the discrete case
    n <- dim(parm$X)[1]
	p <- dim(parm$X)[2]

    #X.mt  <- matrix(as.vector(data$OX),n,p)
	X.mt  <- matrix(as.vector(parm$X),n,p)	
   
    #Probit and Continuous
	
	#ind <- which(X.mt != 0 | X.mt != 1)
	#ind1 <- which(X.mt == 1)	
	#ind0 <- which(X.mt == 0)
 	
	#X.mt[ind]  <- data$OX[ind]
	#X.mt[ind1] <- max( rnorm(length(ind1),mean= 0, sd= 1), 0)
	#X.mt[ind0] <- min( rnorm(length(ind0),mean =0, sd= 1), 0)
		
	num.centers <- parm$G.new

	options(warn=0)
	
        tmp2 <- kmeans(t(X.mt), iter.max=1000, centers=num.centers, nstart=2)
	options(warn=2)

	#
	parm$clust$c.v <- tmp2$cluster
	parm$clust$G <- length(tmp2$size)


	parm$clust$C.m.vec <- array(,parm$clust$G)

	for (g in 1:parm$clust$G)
		{I.g <- (parm$clust$c.v==g)
		 parm$clust$C.m.vec[g] <- sum(I.g)
		}

	###########################

	# start from PDP model with d=0 (i.e DP)
	#parm$d <- 1/3
	parm$d <- 0

	parm
}


fn.eda <- function(parm, data, computeMode)
{

	parm <- fn.init.clusters(parm)
	# reintroduced on 6/29/12
	parm$G.max <- min(parm$p/2, round(parm$clust$G*1.1))
	parm <- fn.poissonDP.hyperparm(data, parm, w=.01, max.d=1)

	parm$Y <- parm$clust$A.mt <- array(,c(parm$n2,parm$clust$G))
	parm$clust$C.m.vec <- array(,parm$clust$G)

	for (g in 1:parm$clust$G)
		{I.g <- (parm$clust$c.v==g)
		 parm$clust$C.m.vec[g] <- m.g <- sum(I.g)
		x.g.v <- parm$X[,I.g]
		 if (m.g > 1)
			{x.g.v <- rowMeans(x.g.v)
			}
		parm$Y[,g] <- x.g.v
		}

	parm$clust$C.m0 <- parm$p - sum(parm$clust$C.m.vec)

	parm$clust$M <- parm$a.R
	parm$clust$M0 <- .01*parm$clust$M

	parm$clust$K <- data$K.max

	########## Fix  DP hyperprior
	######### Starting Values ###
	
	if(parm$discrete == "poisson" ){
	 parm$clust$mu2 <- mean(as.vector(parm$X))
	 parm$clust$tau2 <- diff(range(as.vector(parm$X)))/6
    	}else{
	parm$clust$mu2  <- 0
	parm$clust$tau2 <- 1
	}
	#################################

	parm$g <- rep(1:parm$clust$G,each=parm$n2)
	parm$N <- parm$clust$G * parm$n2

	parm$Y <- as.vector(parm$Y)

	# if (computeMode$useR) {

	tmp <- tryCatch({
	  iter.max <- ifelse((length(parm$Y) > 1000), 10, 1000)
	  kmeans(parm$Y, iter.max = iter.max, centers = data$K.max, nstart = 10,
	         algorithm = "Hartigan-Wong" # TODO: MAcQueen works better?
	  )}, error = function(e) {
	    print("Kmeans did not converge ... using random assignment")
	    cluster <- sample(1:data$K.max, size = length(parm$Y), replace = TRUE)
	    centers <- sapply(1:data$K.max, FUN = function(x) {
	      mean(parm$Y[which(cluster == x)])
	    })
	    list(cluster = cluster, centers = centers, size = data$K.max)
	  })

# 	} else {
#
# 	  tmp <- .fastKMeans(matrix(parm$Y, nrow = 1), data$K.max)
# 	  tmp$cluster <- tmp$cluster + 1
#
# 	}

	parm$clust$s.v <- tmp$cluster
	parm$clust$phi.v <- as.vector(tmp$centers)

	parm$clust$n.vec <- tmp$size
	# number of s equal to 0
	parm$clust$n0 <- 0

	parm$clust$s.mt <- array(parm$clust$s.v, c(parm$n2,parm$clust$G))

	for (g in 1:parm$clust$G)
		{parm$clust$A.mt[,g] <- parm$clust$phi.v[parm$clust$s.mt[,g]]
		}

	sum.resid.sq <- 0

	for (g in 1:parm$clust$G)
		{flag.v <- parm$clust$c.v == g &parm$col.ind ==1
		X.g.mt <- parm$X[,flag.v]
		a.g.v <- parm$clust$A.mt[,g]
		resid.g.mt <- X.g.mt - a.g.v
		sum.resid.sq <- sum.resid.sq + sum(resid.g.mt^2)
		}

	#parm$tau_int <- parm$tau <- sqrt(sum.resid.sq/parm$n2/parm$p)
	p1 <- sum(parm$col.ind)
	parm$tau_int <- parm$tau <- sqrt(sum.resid.sq/parm$n2/p1)

	###################################

	parm$tau_0 <- sqrt(1+parm$tau^2)

	# 1-parm$tau^2/var(as.vector(parm$X))

	## objects of full size (based on all n2 cases)
	parm$clust$B.mt <- cbind(rep(1,parm$n2), parm$clust$A.mt)

	if (parm$tBB_flag)
	  {parm$clust$tBB.mt <- t(parm$clust$B.mt) %*% parm$clust$B.mt
	  }

	parm <- fn.assign.priors(parm, data)

  parm

	}



fn.gen.clust <- function(parm, data, max.row.nbhd.size, row.frac.probes, col.frac.probes, computeMode)
	{


  ###########################################
  # Missing X values
  ###########################################

   n <- dim(data$X)[1]
   p <- dim(data$X)[2]

   X.mt  <- matrix(as.vector(data$X),n, p)
	
  parm$X <- X.mt
  parm$num.X.miss <- sum(is.na(parm$X))
  tmp <- which(is.na(parm$X), arr=TRUE)
  parm$X.missing.x <- tmp[,1]
  parm$X.missing.y <- tmp[,2]

  
  #Probit and Continuous

#   ind <- which(X.mt != 0 & X.mt != 1)
#   ind1 <- which(X.mt == 1)	
#   ind0 <- which(X.mt == 0)
 	
 # X.mt[ind1] <- max( rnorm(length(ind1),mean= 0, sd= 1), 0)
 # X.mt[ind0] <- min( rnorm(length(ind0),mean =0, sd= 1), 0)
 # X.mt[ind]  <- data$OX[ind]
  
	# Impute any missing X values by their column-specific means
	# + a small error term to guarantee non-tied values

 	tmp.mean.v <- apply(parm$X, 2, median, na.rm=TRUE)
	tmp.sd.v <- apply(parm$X, 2, sd, na.rm=TRUE)
	if (parm$num.X.miss>0)
	  { 	for (j in 1:parm$p)
		      {indx.j <- is.na(parm$X[,j])
		      if (sum(indx.j) > 0)
			      {parm$X[indx.j,j] <- tmp.mean.v[j] + rnorm(n=sum(indx.j), sd=tmp.sd.v[j]/5)
		      }
	  }
	}

	##################

	parm$G.new <- data$G.max
	parm <- fn.eda(parm, data, computeMode)

	#################

	parm <- fn.hyperparameters(data, parm)
	parm <- fn.equivsd(parm,data)
	parm <- fn.matrix.sd(parm,data)
	
	parm <- fn.element.DP(data, parm, max.row.nbhd.size, row.frac.probes, computeMode)

	parm$clust$B.mt <- cbind(rep(1,parm$n2), parm$clust$A.mt)

	if (parm$tBB_flag)
	  {parm$clust$tBB.mt <- t(parm$clust$B.mt) %*% parm$clust$B.mt
	  }

	parm

	}

fn.init <- function(true, data, max.row.nbhd.size, row.frac.probes, col.frac.probes, true_parm, tBB_flag, standardize.X, flip.sign, computeMode = "R" , discrete)
	{


#	parm <- true_parm

	parm <- NULL
	parm$col.ind <- data$col.ind
	
	# Discrete
	#parm$logit <- logit
    parm$discrete <- discrete
	#parm$discrete <- true$discrete

	parm$tBB_flag <- tBB_flag
	parm$standardize.X <- standardize.X
	parm$flip.sign <- flip.sign

	parm$n2 <- dim(data$X)[1] # TODO Check
	parm$p <- dim(data$X)[2]  # TODO Check

	### ASSUMING POSITIVE ORIENTATION FOR ALL PDP CLUSTERS
	### IN INITIALIZATION
	parm$clust$orient.v <- rep(1,parm$p)

	# mass parameter of elementwise(s) groups
	# stored later in parm$clust$M
	parm$a.R <- true$a.R

	# mass paramater of columns
	parm$b1 <- true$b1

	# mass paramater of column-intercept cluster
	parm$b0 <- true$b0




#	parm$clust$C.m0 <- 0
#
#	parm$clust$A.mt <- array(,c(parm$n2,parm$clust$G))
#
#	for (g in 1:parm$clust$G)
#		{z.v <- parm$clust$s.mt[,g]>0
#		parm$clust$A.mt[z.v,g] <- parm$clust$phi.v[parm$clust$s.mt[z.v,g]]
#		parm$clust$A.mt[-z.v,g] <- 0
#		}
#
#	parm$clust$B.mt <- cbind(rep(1,parm$n2), parm$clust$A.mt)
#
#	parm$shift <- true$shift
#
#	parm$tau_int <- parm$tau
#
#	parm$X <- data$X

	############################
	# For delta neighborhoods
	############################

	parm$col.delta <- .1

	# delta-neighborhood threshold for elements
	parm$row.delta <- .1

	#########################################
	# generating the R- and C- clusters
	########################################

	parm$shift <- true$shift
	parm <- fn.gen.clust(parm, data, max.row.nbhd.size, row.frac.probes, col.frac.probes, computeMode)

	parm <- fn.assign.priors(parm, data)

	parm

	}


fn.gen.missing.X <- function(data, parm)
{
  # impute missing X values
  #  X.mt <- data$X
  # Discrete Case		
    #Data <- fn.transform(parm,data)
    X.mt <- data$X
	
  if (parm$num.X.miss > 0)
  {
    for (cc in 1:parm$num.X.miss)
    {i.cc <- parm$X.missing.x[cc]
    j.cc <- parm$X.missing.y[cc]
    c.cc <- parm$clust$c.v[j.cc]
    if (c.cc != 0)
    {mean.cc <- parm$clust$A.mt[i.cc, c.cc]
    }
    if (c.cc == 0)
    {mean.cc <- 1
    }
    X.mt[i.cc, j.cc] <- rnorm(n=1, mean=mean.cc, sd=parm$tau)
    }
  }
  parm$X <- X.mt

  parm
}


fn.standardize_orient.X <- function(parm)
{

  ####
  ## STANDARDIZE X columns to unit variance and zero mean
  #####
  # Do only for columns with NA's
  # For other columns, it's just a one-time calculation at the beginning of MCMC

  if (parm$num.X.miss > 0)
    {tmp.X <- matrix(parm$X[,parm$X.missing.y],col=parm$num.X.miss)
    mean.v <- colMeans(tmp.X)
    sd.v <- apply(tmp.X, 2, sd)
    parm$X[,parm$X.missing.y] <- t((t(tmp.X) - mean.v)/sd.v)
   }

  ####
  ## ORIENT X
  ####

  parm$X <- t(t(parm$X) * parm$clust$orient.v)

  parm
}


fn.assign.priors <- function(parm, data)
	{

	parm$prior$tau <- NULL
	parm$prior$tau$alpha.tau <- 1e-2
	parm$prior$tau$beta.tau <- 1e-2

	parm$prior$tau$max <- sqrt(.75)*sd(as.vector(data$X), na.rm=TRUE)
	parm$prior$tau$min <- 1e-10
	parm$prior$tau.sq$max <- parm$prior$tau$max^2
	parm$prior$tau.sq$min <- parm$prior$tau$min^2
	parm$prior$inv.tau.sq$max <- 1/parm$prior$tau.sq$min
	parm$prior$inv.tau.sq$min <- 1/parm$prior$tau.sq$max
	
	parm$prior$mu2$mean <- 0
	parm$prior$mu2$sd   <- 1
	parm$prior$tau2$alpha <- 0.01
	parm$prior$tau2$beta <- 0.01

	parm
	}

########################################
#### This is for the continuous case ###
########################################

fn.gen.tau  <- function(data, parm)
	{
	###################
	# update tau
	###################

	# only covariates assigned to non-zero row and non-zero group clusters matter
	# Need to update the clusters to only continuous columns
  #if(!parm$discrete){

	sum.resid.sq <- 0
	count <- 0

	for (g in 1:parm$clust$G)
		{flag.v <- parm$clust$c.v == g & parm$col.ind == 1
		z.g.v   <- parm$clust$s.mt[,g] > 0
		
		if ((sum(z.g.v) > 0) & (sum(flag.v)>0) )
			{
		
			X.g.mt <- parm$X[z.g.v,flag.v]
			a.g.v <- parm$clust$A.mt[z.g.v,g]
			resid.g.mt <- X.g.mt - a.g.v
			sum.resid.sq <- sum.resid.sq + sum(resid.g.mt^2)
			count <- count + sum(z.g.v)*sum(flag.v)
			}

		}

	shape <- parm$prior$tau$alpha + count/2
	rate <- parm$prior$tau$beta + sum.resid.sq/2

	u.min <- pgamma(parm$prior$inv.tau.sq$min,shape=shape, rate=rate)
	u.max <- pgamma(parm$prior$inv.tau.sq$max,shape=shape, rate=rate)
	gen.u <- runif(n=1, min=u.min, max=u.max)

    parm$tau <- 1/sqrt(qgamma(gen.u,shape=shape, rate=rate))
	
	# This manouever is useful for large n, p (n < p) cases
	#parm$tau <- 1/sqrt(rgamma(1,shape=shape, rate=rate))
	

	# overwrite to avoid zeros and Inf
	if (round(u.min, digits = 5) == 1) # really close to 1
		{parm$tau<- 1/sqrt(parm$prior$inv.tau.sq$min)
		}
	if (round(u.max, digits = 5) == 0) # really close to 0
		{parm$tau<- 1/sqrt(parm$prior$inv.tau.sq$max)
		}

	###################
	# update tau_int
	###################

	# only covariates assigned to intercept cluster matter

	#sum.resid.sq <- 0
	#flag.v <- parm$clust$c.v == 0
	#count <- parm$clust$C.m0*parm$n2

	#if (parm$clust$C.m0>0)
	#		{X.g.mt <- parm$X[,flag.v]
	#		a.g.v <- rep(1,parm$n2)
	#		resid.g.mt <- X.g.mt - a.g.v
	#		sum.resid.sq <- sum.resid.sq + sum(resid.g.mt^2)
	#		}


	#shape <- parm$prior$tau$alpha + count/2
	#rate <- parm$prior$tau$beta + sum.resid.sq/2

	# shares same support as parm$tau
	#u.min <- pgamma(parm$prior$inv.tau.sq$min,shape=shape, rate=rate)
	#u.max <- pgamma(parm$prior$inv.tau.sq$max,shape=shape, rate=rate)
	#gen.u <- runif(n=1, min=u.min, max=u.max)

    #parm$tau_int <- 1/sqrt(qgamma(gen.u,shape=shape, rate=rate))

    #parm$tau_int <- 1/sqrt(qgamma(gen.u,shape=shape, rate=rate))

	#if (gen.u < 1e-5)
	#	{parm$tau_int <- 1/sqrt(parm$prior$inv.tau.sq$max)
	#	}
	#if ((1-gen.u) < 1e-5)
	#	{parm$tau_int <- 1/sqrt(parm$prior$inv.tau.sq$min)
	#	}

	#}else{
	
	#parm$tau_int <- 1
    #  	}

	parm
	}

########################################

########################################



fn.gen.tau_0  <- function(data, parm)
	{
	###################
	# update tau_0
	###################

    if(!parm$discrete){
	
	sum.resid.sq <- 0
	count <- 0

	for (g in 1:parm$clust$G)
		{flag.v <- parm$clust$c.v == g
		z.g.v <- parm$clust$s.mt[,g] > 0

		if ((sum(1-z.g.v) > 0) & (sum(flag.v)>0))
			{X.g.mt <- parm$X[!z.g.v,flag.v]
			resid.g.mt <- X.g.mt
			sum.resid.sq <- sum.resid.sq + sum(resid.g.mt^2)
			count <- count + sum(1-z.g.v)*sum(flag.v)
			}
		}

	shape <- 1 + count/2
	rate <- 1 + sum.resid.sq/2

	# minimum possible value of parm$tau_0 = 1.5 * maximum possible value of parm$tau
	# maximum possible value of parm$tau_0 = 3 * sd(as.vector(data$X))
	u.min <- pgamma(1/9 / var(as.vector(data$X),na.rm=TRUE),shape=shape, rate=rate)
	u.max <- pgamma(1/1.5^2/parm$prior$tau.sq$min,shape=shape, rate=rate)
	gen.u <- runif(n=1, min=u.min, max=u.max)

      parm$tau_0 <- 1/sqrt(qgamma(gen.u,shape=shape, rate=rate))

    }else{
	
	parm$tau_0 <- 1

	}
	parm
	}

###############################################################################
# Updating Sd for each covariates 
###############################################################################

fn.disc.tau <- function(parm,data)
	{
	parm$clust$sd.v <- NULL
	
	
	# data$OX
  	n <- dim(data$OX)[1]
  	p <- dim(data$OX)[2]
	sd  <- matrix(NA,n,p)

	for (xx in 1:p ){
	s.v      <- parm$clust$s.mt[,parm$clust$c.v[xx]]
	theta.v  <- parm$clust$phi.v[s.v]
	
  	# Numerical Stability
  	log.p      <-  -log( 1 + exp(theta.v))  +  theta.v
  	log.var    <-	-2*log(1 + exp(theta.v))  +  theta.v

	sd[,xx]    <- sqrt(1/exp(log.var))
	
	}

	parm$clust$sd.v <- sd
	
parm
}




fn.hyperparameters <- function(data, parm)
	{

	# also updates update tau_int
	parm <- fn.gen.tau(data, parm)

	#parm <- fn.gen.tau_0(data, parm)

	parm

	}


fn.funky <- function(s,t)
	{# on log scale
	lgamma(s+t) - lgamma(s)
	}

fn.d <- function(d, parm)
	{

	# formula in review paper by Lijoi and Prunster
	log.lik <- sum(log(parm$b1 + (1:(parm$clust$G-1))*d)) - fn.funky((parm$b1+1), (parm$p-1)) + sum(fn.funky((1-d), (parm$clust$C.m.vec-1)))

	log.lik
	}




fn.poissonDP.hyperparm <- function(data, parm, w=.01, max.d)
	{


	## update parm$d conditional on parm$b1
	## 1/w must be an integer

	d.v <- seq(0,max.d,by=w)
	len <- length(d.v)
	d.v <- d.v[-len]
	len <- len-1

	log.lik.v <- sapply(d.v, fn.d, parm)
	# putting 1/2 prior mass on 0 and remaining spread uniformly on positive points in d.v
	log.p.v <- log(.5) + c(0,  rep(-log(len-1),(len-1)))

	log.post.v <- log.lik.v + log.p.v
	log.post.v <- log.post.v - max(log.post.v)
	post.v <- exp(log.post.v)
	post.v <- post.v/sum(post.v)

	# plot(d.v, post.v, type="l")

	prop.d <- sample(d.v, size=1, prob=post.v)

	if (prop.d > 0)
		{prop.d <- runif(n=1, min=(prop.d-w), max=(prop.d+w))
		}

	if (prop.d != parm$d)
		{
		# MH ratio for independent proposals and
		# prior same for all d (which is true if 0 wp .5 and \in (0,max.d) wp .5)

		log.ratio <- fn.d(d=prop.d, parm) - fn.d(d=parm$d, parm)
		prob <- min(1, exp(log.ratio))
		flip <- rbinom(n=1, size=1, prob=prob)
		if (flip==1)
			{parm$d <- prop.d
			}
		}
	#parm$d <- 1/3	
	
		
	parm

	}


fn.DP.hyperparameters <- function(parm, data){

		

	post.mu.prec    <- parm$clust$K/parm$clust$tau2^2 + 1/parm$prior$mu2$sd^2
	post.mu.mean	<- 1/post.mu.prec * ( sum(parm$clust$phi.v)/parm$clust$tau2^2 + parm$prior$mu2$mean/parm$prior$mu2$sd^2 )
	parm$clust$mu2  <- rnorm(1,post.mu.mean,sqrt(1/post.mu.prec) )
	
	
	post.sigma.shape <- parm$prior$tau2$alpha + parm$clust$K/2
	post.sigma.rate  <- parm$prior$tau2$beta + t(parm$clust$phi.v -parm$clust$mu2)%*%(parm$clust$phi.v -parm$clust$mu2)/2 
	parm$clust$tau2   <- sqrt(1/rgamma(1,post.sigma.shape, scale = 1/post.sigma.rate))


parm

}	


########################################

fn.iter <- function(data, parm, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm,
                    computeMode)
	{

	data <- fn.transform(parm,data)
	parm$X <- data$X
	
	parm <- fn.equivsd(parm,data)	
	
	parm <- fn.matrix.sd(parm,data)
	
	parm <- fast_PDP_fn.main(parm, data, col.frac.probes, prob.compute.col.nbhd, max.col.nbhd.size, computeMode)

	parm <- fn.element.DP(data, parm, max.row.nbhd.size, row.frac.probes, computeMode)
	
	parm <- fn.poissonDP.hyperparm(data, parm, w=.01, max.d=1)
	
	#if(parm$discrete !="poisson" ){
	#parm <- fn.DP.hyperparameters(parm,data)
	#}
	parm <- fn.hyperparameters(data, parm)

	flip <- rbinom(n=1, size=1, prob=.1)
	if (flip==1)
	  {parm <- fn.gen.missing.X(data, parm)
	}

	if (parm$flip.sign)
	  {
	    ############
	    ## Update signs for updated columns
	    ############
	    parm <- PDP_fn.orientation(parm, cc_subset=1:parm$p)
	  }

	if (parm$standardize.X)
	  {parm <- fn.standardize_orient.X(parm)
	  }

	parm$clust$B.mt <- cbind(rep(1,parm$n2), parm$clust$A.mt)
	if (parm$tBB_flag)
	  {parm$clust$tBB.mt <- t(parm$clust$B.mt) %*% parm$clust$B.mt
	  }

	err <- fn.quality.check(parm)
	if (err > 0)
		{stop(paste("failed QC: err=",err))
		}

	parm


	}



fn.mcmc <- function(text, true, data, n.burn, n.reps, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm, dahl.flag=FALSE,
                    standardize.X=FALSE, flip.sign=FALSE, tBB_flag=FALSE, computeMode = "R" ,discrete)
	{

	# initialize
	parm <- fn.init(true, data, max.row.nbhd.size, row.frac.probes, col.frac.probes, true_parm, tBB_flag, standardize.X, flip.sign, computeMode , discrete)
    #parm <- fn.equivsd(parm, data )
	init.parm <- parm

	
	err <- fn.quality.check(parm)
	if (err > 0)
		{stop(paste("failed QC at fn.init: err=",err))
		}

	for (cc in 1:n.burn)
		{
		#data <- fn.transform(parm,data)	
		#sum(is.na(data$X))
		parm <- fn.iter(data, parm, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm, computeMode)

		if (cc %% 10 == 0)
			{print(paste(text, "BURN = ",cc,date(),"***********"))
			}
		}

	##########################################
	## first get an estimated G cluster
	##########################################


	All.Stuff <- NULL
	#
	All.Stuff$tau2.v <-All.Stuff$d.v <- All.Stuff$tau_0.v <- All.Stuff$tau.v <- All.Stuff$tau_int.v <- All.Stuff$G.v <- All.Stuff$K.v <- array(,n.reps)
	All.Stuff$row.flip.v  <- array(0,n.reps)
	All.Stuff$nbhd_max <- All.Stuff$col_new_clust.v  <- All.Stuff$col_exit.v <- All.Stuff$col_flip.v  <- array(0,n.reps)

	All.Stuff$pi.mt <- array(0,c(parm$p,parm$p))
	All.Stuff$mean.taxicab.v  <- array(0,n.reps)

	if (dahl.flag)
	  {All.Stuff$c.matrix <- array(0,c(n.reps,parm$p))
	  }


	for (cc in 1:n.reps)
		{
		#data <- fn.transform(parm,data)	
		parm <- fn.iter(data, parm, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm, computeMode)

		All.Stuff$G.v[cc] <- parm$clust$G
		All.Stuff$K.v[cc] <- parm$clust$K
		All.Stuff$tau.v[cc] <- parm$tau
		All.Stuff$tau_0.v[cc] <- parm$tau_0
		All.Stuff$tau_int.v[cc] <- parm$tau_int
		All.Stuff$tau2.v[cc]   <- parm$clust$tau2

		All.Stuff$d.v[cc] <- parm$d

		if (dahl.flag)
		{All.Stuff$c.matrix[cc,] <- parm$clust$c.v
		}


		# summarizing elementwise DP in "fn.groupwise.updates"

		All.Stuff$row.flip.v[cc]  <- parm$clust$row.flip

		All.Stuff$col_new_clust.v[cc]  <- parm$clust$col.new.flag
		All.Stuff$col_flip.v[cc]  <- parm$clust$col.mh.flip
		All.Stuff$col_exit.v[cc]  <- parm$clust$col.mh.exit

		tmp.mat <- array(0,c(parm$p,parm$p))

		for (jj in 1:parm$clust$G)
			{indx.jj <- which(parm$clust$c.v==jj)
			tmp.mat[indx.jj,indx.jj] <- 1
		}

		All.Stuff$pi.mt <- All.Stuff$pi.mt + tmp.mat

		p<-All.Stuff$mean.taxicab.v[cc] <- mean(true_parm$clust$nbhd.matrix != tmp.mat)

		All.Stuff$nbhd_max[cc] <- round(parm$clust$nbhd_max_dist, digits = 2)

		if (cc %% 10 == 0)
			{print(paste(text, "REPS = ",cc,date(),p,"***********"))
			}

		} # end for loop in cc


	All.Stuff$pi.mt <- All.Stuff$pi.mt/n.reps

	All.Stuff$parm <- parm
	All.Stuff$init.parm <- init.parm

	###

	if (dahl.flag)
	{#update this loop later
	 }

	All.Stuff
	}

