
####################################
## Set working directory ###########
####################################

wkdir <- "C:\\Users\\Certified Copy\\Workspace\\Guha\\Laplace Approximation\\Variscan-Mixed-L"
setwd(wkdir)

library(msm)
source("dahl.R")
source("elementwise_DP.functions.R")
source("elementwise_main.R")
source("fast_PDP.functions.R")
source("gen.clust.R")
source("gen.X.R")
source("iterations.R")
source("lso.R")
source("NPCluster.R")
source("profile_code.R")
#source("profitable.R")
source("RcppExports.R")
source("split.merge.R")
source("variable.PDP.functions.R")



# Initial Paramters
n.burn = 1000
n.reps = 2000
max.row.nbhd.size = round(.1*25*125^.5)
max.col.nbhd.size = round(.05*125)
row.frac.probes = 0.05
col.frac.probes = .1
prob.compute.col.nbhd=.2
dahl.flag=FALSE
standardize.X=FALSE
flip.sign=FALSE
tBB_flag=FALSE
computeMode = createComputeMode()
logit = FALSE



SimulateExample  <- function(n = 25, p = 250,prop.X.cont=.5, prop.X.miss=0, tau = 1, tau_0 =1, discrete) {

	###################
	# generate covariates adding random noise of specified level
	# create objects data and true
	###################

	true_parm <- gen.clust(n, p)

	true_parm$tau <- tau
	true_parm$tau_0 <- tau_0
         
        true_parm$discrete <- discrete	

	sim.X <- gen.X(n, p,prop.X.cont, prop.X.miss, true_parm)

	simulation <- list(X = sim.X, parm = true_parm)
	class(simulation) <- "NPClustSimulation"

	return(simulation)
}

fitExample <- function(data,
											 n.burn = 10,
											 n.reps = 20,
											 max.row.nbhd.size = round(.1*25*125^.5), # should be small compared to n2*p^d (~ n2*G if d=.5)
											 max.col.nbhd.size = round(.05*125), # should be small compared to p
											 row.frac.probes = 0.05,
											 col.frac.probes = .1,
                       prob.compute.col.nbhd=.2,
											 dahl.flag=FALSE,
											 standardize.X=FALSE,
											 flip.sign=FALSE,
											 tBB_flag=FALSE,
											 computeMode = createComputeMode() , discrete ) {

	if (!inherits(data, "NPClustSimulation")) {
		stop("Wrong data structure")
	}

  if (!inherits(computeMode, "computeMode")) {
    stop("Wrong compute mode")
  }

  if (!standardize.X & flip.sign) {
    stop("Invalid input parameters-- flip.sign cannot be TRUE when standardize.X is FALSE")
  }


	###################
	# Detect clusters
	###################

	posterior <- fn.mcmc(text="CLUST ANALYZE...",
											 data$X$true, data$X$data,
											 n.burn, n.reps, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes,
											 prob.compute.col.nbhd, data$parm, dahl.flag=dahl.flag, standardize.X, flip.sign, tBB_flag, computeMode, discrete)
	return (posterior)
}

#' @export
profileExample <- function(n = 25,
													 p = 250,
													 n.burn = 10,
													 n.reps = 20,
													 row.frac.probes = 0.05,
													 col.frac.probes = 0.05,
													 computeMode = createComputeMode(),
													 filename = "Rprof.out") {
	simulation <- simulateExample(n, p)

	Rprof(filename = filename, line.profiling = TRUE, interval = 0.001)
	posterior <- fitExample(simulation, n.burn = n.burn, n.reps = n.reps,
	           row.frac.probes = row.frac.probes,
	           col.frac.probes = col.frac.probes,
	           computeMode = computeMode)
	Rprof(NULL)
	#summaryRprof(lines = "show")$by.self
	return(posterior)
}


#' createComputeMode
#' @export
createComputeMode <- function(language = "R",
                              exactBitStream = FALSE,
                              extraSort = TRUE,
                              completeTest = FALSE,
                              tolerance = 1E-10,
                              test1 = FALSE,
                              test2 = FALSE,
                              test3 = FALSE) {
  if (!(language %in% c("C","R"))) {
    stop("Invalid language")
  }

  useR <- (language == "R")
  device <- NULL
  if (!useR) {
    doSort <- (exactBitStream | extraSort)
    device <- .createEngine(doSort)
  }

  object <- list(
    computeR = (language == "R" | completeTest),
    computeC = (language == "C"),
    device = device,
    exactBitStream = exactBitStream,
    extraSort = extraSort,
    tolerance = tolerance,
    test1 = test1,
    test2 = test2,
    test3 = test3
  )
  class(object) <- "computeMode"
  return(object)
}

#' assertEqual
assertEqual <- function(x, y, tolerance = 0) {
  if (length(x) != length(y)) {
    stop(cat("C++ error -- length:", length(x), length(y)))
  }
  if (any(abs(x - y) > tolerance)) {
    stop(cat("C++ error -- value:", x, y, tolerance, sep = "\n"))
  }
}



data <- SimulateExample()
data <- SimulateExample(n = 25, p = 250, prop.X.cont =0.5, prop.X.miss=0, 1,1, probit)
#data <- data$X$data

posterior <- fn.mcmc(text="CLUST ANALYZE...",
											 data$X$true, data$X$data,
											 n.burn, n.reps, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes,
											 prob.compute.col.nbhd, data$parm, dahl.flag=dahl.flag, standardize.X, flip.sign, tBB_flag, computeMode, logit)
true <- data$X$true
data <- data$X$data

Run <-fitExample(data,
											 n.burn = 10,
											 n.reps = 20,
											 max.row.nbhd.size = round(.1*25*125^.5), # should be small compared to n2*p^d (~ n2*G if d=.5)
											 max.col.nbhd.size = round(.05*125), # should be small compared to p
											 row.frac.probes = 0.05,
											 col.frac.probes = .1,
                       prob.compute.col.nbhd=.2,
											 dahl.flag=FALSE,
											 standardize.X=FALSE,
											 flip.sign=FALSE,
											 tBB_flag=FALSE,
											 computeMode = createComputeMode(),discrete ="probit")