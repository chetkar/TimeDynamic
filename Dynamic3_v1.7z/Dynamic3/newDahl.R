
fn.Dahl <- function(parm, All.Stuff, dahl.flag)
{### Dahl calculations
  
  parm$dahlDist.mt <- list(array(,c(parm$h) ) )	  
	
  for(l in 1:parm$h ){  

  tmp.mat <- array(0,c(parm$p,parm$p))
  
  for (jj in 1:parm$clust$G[[l]])
  {indx.jj <- which(parm$clust$c.v[[l]]==jj)
  tmp.mat[indx.jj,indx.jj] <- 1
  }
  
  parm$dahlDist.mt[[l]] = tmp.mat

  }
  
    
  if (dahl.flag)
  {# interpretation: square of this is double the total number of mismatching pairs of allocations
    parm$Dahl_dist =  sqrt(sum((unlist(parm$dahlDist.mt) - unlist(All.Stuff$meanDahlDist.mt))^2))
  
  if (parm$Dahl_dist < parm$min_Dahl_dist)
  {parm$min_Dahl_dist = parm$Dahl_dist
  	
	for(l in 1:parm$h ){
		parm$est_c.v[[l]]  <- parm$clust$c.v[[l]]
	}
  }
  }
  
  parm
}
